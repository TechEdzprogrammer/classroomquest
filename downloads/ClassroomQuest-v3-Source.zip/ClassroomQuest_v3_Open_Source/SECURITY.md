# Security & privacy

Classroom Quest Offline is designed for a **single trusted classroom LAN** and does not offer internet-grade authentication or TLS. **Do not expose the game server to the public internet.**

- The teacher dashboard, question bank, subject changes, network settings, backup/restore and shutdown are restricted to requests from the host laptop using `localhost` or a loopback address.
- Pupil browsers can join one of two team slots, submit a single answer per open question, and view the current round results. They cannot access the unpublished answer key before the round is finished.
- Treat phone join tokens like temporary secrets. To release a missing phone, use **More controls → Release Team** on the teacher dashboard.
- Use a password-protected local Wi-Fi/hotspot. Avoid public/guest networks and Wi-Fi client isolation.
- If Windows Firewall asks for a network exception, choose **Private networks** only; do not disable your firewall.
- No account, external service, telemetry or advertisement is used by the application. Data files are under `%LOCALAPPDATA%\TechEdz\Classroom Quest Offline\data`.
- The app stores teacher-entered questions, team names and score records locally. Teachers should avoid entering pupil identifiers or other sensitive information.
- Keep backups secure. The JSON backup contains the full question bank and the correct answer keys.
- Browser audio remains local to the devices and runs without sending information to an external audio provider.

For security issues, contact the project maintainer through their public project issue tracker or another contact channel published by TechEdz. Do not include sensitive pupil data or exploit details in public bug reports.
