# Build Classroom Quest Offline v3.0

Requires Go **1.23+** for developers only. Teachers do not install any development dependencies.

## Run the tests

```bash
cd app
go test -race ./...  # Linux/macOS; on Windows use: go test ./...
```

## Compile the portable desktop executable (Windows 64-bit)

From `app`:

```powershell
go build -ldflags="-s -w -H=windowsgui" -o ClassroomQuest.exe .
```

Or cross-compile on Linux/macOS:

```bash
GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -ldflags='-s -w -H=windowsgui' -o ClassroomQuest.exe .
```

The binary embeds the HTML/CSS/JS, offline audio, starter questions, HTTP server and game engine.

## Compile the per-user Windows installer

From `installer`:

1. Copy the newly built `ClassroomQuest.exe` into `installer/payload/`.
2. Build `uninstaller.go` as `payload/Uninstall.exe`.
3. Keep the provided ICO and `QUICK_START.txt` in `payload/`.
4. Build `installer.go` as `ClassroomQuest-Setup.exe`.

Example on Linux:

```bash
cd installer
GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -ldflags='-s -w -H=windowsgui' -o payload/Uninstall.exe uninstaller.go
GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -ldflags='-s -w -H=windowsgui' -o ClassroomQuest-Setup.exe installer.go
```

The per-user installer adds a desktop shortcut and Start menu entry without administrator elevation. It does not delete teacher data on uninstall.

## Source layout

- `app/main.go` — HTTP/API, persisted data, teacher-only access, migration.
- `app/engine.go` — match state and scoring rules.
- `app/network.go`, `app/qr.go` — LAN detection and QR code.
- `app/public/` — vanilla HTML/CSS/JS and original offline WAV loop.
- `app/seed/question-bank.json` — editable starter questions.
- `installer/` — Windows installer and uninstaller (Go).

## Release checklist

- [ ] Go tests pass.
- [ ] JavaScript syntax checks pass.
- [ ] Real Windows 10 and Windows 11 install/uninstall tested.
- [ ] Two real phones join over hotspot, both can answer, and scores correct.
- [ ] Learner audio plays only when enabled, is muted when disabled, and music stops at the end of the match.
- [ ] v2.x upgrade retains teacher banks. New subject names survive restart.
- [ ] Code-sign installer for wider distribution. Published download checksum verified.

The bundled installer is currently **unsigned**, and cross-compilation is not a substitute for a live Windows installation test.
