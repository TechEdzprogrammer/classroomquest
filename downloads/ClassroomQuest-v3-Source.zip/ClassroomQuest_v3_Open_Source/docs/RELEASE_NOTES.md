# Classroom Quest v3.0 — release notes

- Replace fixed subject list with saved, editable learning areas (add, rename, remove).
- Prevent accidental data loss on removal with a confirmation and local safety backup.
- Support subject names across elementary and secondary levels.
- JSON backups now include subject names (schema v2), while v1 backups remain importable.
- Add original offline chill WAV loop on teacher dashboard and soft synthesized correct/wrong sound effects on teacher and learner screens.
- Music and sounds are optional; no downloads or internet connections are required.
- Retain separated dashboard, question editor, instructions and learner views, with secondary controls collapsed.
- Retain existing game rules: two teams, one point per correct answer, teacher-selected target, server-side validation and tie-breakers.
- Add MIT License, contribution guide, security/privacy notes, build instructions and teacher quick start.
- Build outputs are unsigned and require real-world testing before large-scale distribution.
