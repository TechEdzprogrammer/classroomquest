# Contributing

Thank you for supporting accessible public-school classroom technology.

1. Check existing issues or discussions before proposing a major change.
2. Keep offline-first design: **no mandatory package install for teachers**, online accounts or CDNs.
3. Maintain accessibility, readable mobile screens and simple teacher workflows. Keep advanced options behind expandable sections where possible.
4. Submit a focused change with automated tests (`go test ./...`) and browser compatibility notes.
5. Never commit real student/pupil data, credentials, or privately authored test questions without permission.
6. Use permissively licensed dependencies or original assets; document attribution and licenses.
7. Preserve existing question banks, saved learning areas, and scoring behavior in upgrades.

All submitted contributions should be suitable for distribution under the project's MIT License.
