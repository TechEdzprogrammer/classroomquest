// TechEdz Classroom Quest Offline per-user installer.
// Requires only Windows 10/11 x64. No administrator elevation, Node.js, Python,
// npm, internet, or Microsoft Store is needed at the time of installation.
package main

import (
 "embed"
 "fmt"
 "io/fs"
 "os"
 "os/exec"
 "path/filepath"
 "strings"
 "syscall"
 "unsafe"
)

//go:embed payload/*
var payload embed.FS

const version = "3.0.0"

func message(title, body string, flags uintptr) int {
 user32 := syscall.NewLazyDLL("user32.dll")
 proc := user32.NewProc("MessageBoxW")
 t, _ := syscall.UTF16PtrFromString(title)
 b, _ := syscall.UTF16PtrFromString(body)
 result, _, _ := proc.Call(0, uintptr(unsafe.Pointer(b)), uintptr(unsafe.Pointer(t)), flags)
 return int(result)
}
func run(name string, args ...string) error {
 c := exec.Command(name, args...)
 c.SysProcAttr = &syscall.SysProcAttr{HideWindow: true}
 out, err := c.CombinedOutput()
 if err != nil { return fmt.Errorf("%s: %v — %s", name, err, string(out)) }
 return nil
}
func psQuote(value string) string { return "'" + strings.ReplaceAll(value,"'","''") + "'" }
func shortcut(target, path, icon, folder string) string {
 return fmt.Sprintf("$s=$shell.CreateShortcut(%s);$s.TargetPath=%s;$s.WorkingDirectory=%s;$s.IconLocation=%s;$s.Description='TechEdz Classroom Quest Offline';$s.Save();", psQuote(path),psQuote(target),psQuote(folder),psQuote(icon))
}
func makeShortcuts(dir string) error {
 app := filepath.Join(dir,"ClassroomQuest.exe")
 icon := filepath.Join(dir,"ClassroomQuest.ico")
 start := filepath.Join(os.Getenv("APPDATA"),"Microsoft","Windows","Start Menu","Programs","Classroom Quest Offline.lnk")
 powershell := "$ErrorActionPreference='Stop';$shell=New-Object -ComObject WScript.Shell;"+
  shortcut(app,start,icon,dir)+
  "$desktop=[Environment]::GetFolderPath('Desktop');"+
  shortcut(app,"DYNAMIC_DESKTOP_LINK",icon,dir)
 powershell = strings.ReplaceAll(powershell,psQuote("DYNAMIC_DESKTOP_LINK"),"(Join-Path $desktop 'Classroom Quest Offline.lnk')")
 return run("powershell.exe","-NoProfile","-NonInteractive","-Command",powershell)
}
func regAdd(key,name,value string)error{return run("reg.exe","add",key,"/v",name,"/t","REG_SZ","/d",value,"/f")}
func registry(dir string) error {
 key:=`HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\TechEdzClassroomQuestOffline`
 pairs:=[][2]string{{"DisplayName","Classroom Quest Offline (TechEdz)"},{"DisplayVersion",version},{"Publisher","TechEdz"},{"InstallLocation",dir},{"UninstallString",`"`+filepath.Join(dir,"Uninstall.exe")+`"`},{"DisplayIcon",filepath.Join(dir,"ClassroomQuest.ico")}}
 for _,p:=range pairs {if err:=regAdd(key,p[0],p[1]);err!=nil{return err}}
 return nil
}
func install()error{
 home:=os.Getenv("LOCALAPPDATA")
 if home==""{return fmt.Errorf("Windows LOCALAPPDATA folder could not be found")}
 dir:=filepath.Join(home,"Programs","Classroom Quest Offline")
 if err:=os.MkdirAll(dir,0755);err!=nil{return err}
 files:=[]string{"ClassroomQuest.exe","ClassroomQuest.ico","QUICK_START.txt","Uninstall.exe"}
 for _,filename:=range files {
  data,err:=fs.ReadFile(payload,"payload/"+filename);if err!=nil{return err}
  file:=filepath.Join(dir,filename)
  // A running app cannot be overwritten on Windows. In this case, the user should close it first.
  if err:=os.WriteFile(file,data,0644);err!=nil{return fmt.Errorf("Cannot install %s. Please close Classroom Quest before upgrading. (%w)",filename,err)}
 }
 shortcutErr:=makeShortcuts(dir)
 registryErr:=registry(dir)
 if shortcutErr!=nil || registryErr!=nil {
  return fmt.Errorf("The app was copied to %s but Windows could not create some shortcuts or app-list entries. Shortcut error: %v; registry error: %v",dir,shortcutErr,registryErr)
 }
 return nil
}
func main(){
 if message("Classroom Quest Offline — TechEdz", "Install Classroom Quest Offline v3.0?\n\nThis will add an easy-to-use desktop icon and Start menu shortcut. The quiz runs without Node.js or internet.\n\nYour saved questions and learning areas are preserved in your Windows user folder.\n\nSelect OK to install, or Cancel to exit.",0x1|0x40)!=1{return}
 if err:=install();err!=nil{message("Installation needs attention",err.Error(),0x10);return}
 if message("Classroom Quest — Installed!", "Classroom Quest Offline was installed successfully.\n\n1. Open Classroom Quest from the desktop.\n2. Open Instructions and choose your connection type.\n3. Connect both phones to the same network.\n4. Scan the QR code and open the Teacher Dashboard.\n\nWould you like to launch Classroom Quest now?",0x4|0x40)==6 {
  exe:=filepath.Join(os.Getenv("LOCALAPPDATA"),"Programs","Classroom Quest Offline","ClassroomQuest.exe")
  cmd:=exec.Command(exe);cmd.Dir=filepath.Dir(exe);cmd.SysProcAttr=&syscall.SysProcAttr{HideWindow:true};if err:=cmd.Start();err!=nil{message("Unable to launch",err.Error(),0x10)}else{_ = cmd.Process.Release()}
 }
}
