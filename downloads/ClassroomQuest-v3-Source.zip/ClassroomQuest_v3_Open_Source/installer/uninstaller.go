package main

import (
 "fmt"
 "net/http"
 "os"
 "os/exec"
 "path/filepath"
 "strings"
 "syscall"
 "time"
 "unsafe"
)
func message(title,body string,flags uintptr)int{
 user32:=syscall.NewLazyDLL("user32.dll");proc:=user32.NewProc("MessageBoxW")
 t,_:=syscall.UTF16PtrFromString(title);b,_:=syscall.UTF16PtrFromString(body)
 ret,_,_:=proc.Call(0,uintptr(unsafe.Pointer(b)),uintptr(unsafe.Pointer(t)),flags);return int(ret)
}
func cmd(name string,args ...string) {x:=exec.Command(name,args...);x.SysProcAttr=&syscall.SysProcAttr{HideWindow:true};_ = x.Run()}
func psQuote(s string)string{return "'"+strings.ReplaceAll(s,"'","''")+"'"}
func power(script string){cmd("powershell.exe","-NoProfile","-NonInteractive","-Command",script)}
func main(){
 home:=os.Getenv("LOCALAPPDATA");if home==""{message("Classroom Quest","Unable to find LocalAppData.",0x10);return}
 dir:=filepath.Join(home,"Programs","Classroom Quest Offline")
 if _,err:=os.Stat(filepath.Join(dir,"ClassroomQuest.exe"));err!=nil{message("Classroom Quest","Classroom Quest is not installed in the standard location.",0x40);return}
 if message("Uninstall Classroom Quest","Remove Classroom Quest from this PC?\n\nYour saved question banks and game data will be KEPT in AppData.",0x1|0x20)!=1{return}
 client:=http.Client{Timeout:400*time.Millisecond}
 for port:=3000;port<=3010;port++{
  resp,err:=client.Get(fmt.Sprintf("http://127.0.0.1:%d/api/health",port))
  if err==nil{resp.Body.Close();if resp.StatusCode==200{message("Close the game first","Please click Exit app in the Classroom Quest teacher dashboard, then run Uninstall again.",0x30);return}}
 }
 start:=filepath.Join(os.Getenv("APPDATA"),"Microsoft","Windows","Start Menu","Programs","Classroom Quest Offline.lnk")
 cmd("powershell.exe","-NoProfile","-NonInteractive","-Command",fmt.Sprintf("Remove-Item -LiteralPath %s -Force -ErrorAction SilentlyContinue; $d=[Environment]::GetFolderPath('Desktop'); Remove-Item -LiteralPath (Join-Path $d 'Classroom Quest Offline.lnk') -Force -ErrorAction SilentlyContinue",psQuote(start)))
 key:=`HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\TechEdzClassroomQuestOffline`
 cmd("reg.exe","delete",key,"/f")
 _ = os.Remove(filepath.Join(dir,"ClassroomQuest.exe"));_ = os.Remove(filepath.Join(dir,"ClassroomQuest.ico"));_ = os.Remove(filepath.Join(dir,"QUICK_START.txt"))
 message("Classroom Quest","Uninstallation complete.\n\nPersonal question banks were preserved in AppData.",0x40)
 // Delete the uninstaller and remaining install folder after this process exits.
 script:=fmt.Sprintf("Start-Sleep -Seconds 2; Remove-Item -LiteralPath %s -Recurse -Force -ErrorAction SilentlyContinue",psQuote(dir))
 p:=exec.Command("powershell.exe","-NoProfile","-NonInteractive","-WindowStyle","Hidden","-Command",script);p.SysProcAttr=&syscall.SysProcAttr{HideWindow:true};_ = p.Start();if p.Process!=nil{_ = p.Process.Release()}
}
