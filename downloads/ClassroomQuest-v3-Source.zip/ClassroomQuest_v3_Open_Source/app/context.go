package main

import (
	"context"
	"time"
)

func newShutdownContext() (context.Context, context.CancelFunc) {
	return context.WithTimeout(context.Background(), 3*time.Second)
}
