'use strict';
window.CQ = (() => {
  const SUBJECTS = ['GMRC','Makabansa','Math','Science','English','Filipino'];
  function escapeHTML(value) {
    return String(value == null ? '' : value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  }
  async function api(url, method='GET', body) {
    const options = { method, headers:{} };
    if (body !== undefined) { options.headers['Content-Type']='application/json'; options.body=JSON.stringify(body); }
    let response;
    try { response = await fetch(url,options); }
    catch { throw new Error('Cannot connect to the classroom laptop. Check your hotspot connection.'); }
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || `Request failed (${response.status})`);
    return data;
  }
  const toastTimers = new Map();
  function toast(id,message,isError=false) {
    const el = document.getElementById(id);
    if (!el) return;
    el.textContent=message; el.classList.toggle('error',isError); el.classList.add('show');
    clearTimeout(toastTimers.get(id));
    toastTimers.set(id,setTimeout(() => el.classList.remove('show'),4200));
  }
  return { SUBJ:SUBJECTS,esc:escapeHTML,api,toast };
})();
