'use strict';
// All audio is created for Classroom Quest and packaged locally. No external CDNs.
window.CQAudio=(()=>{
  const key='cq_audio_v3_';
  const get=(name,fallback)=>{try{const v=localStorage.getItem(key+name);return v===null?fallback:v==='1';}catch{return fallback;}};
  const save=(name,value)=>{try{localStorage.setItem(key+name,value?'1':'0');}catch{}};
  let musicOn=get('music',false), sfxOn=get('sfx',true), active=false, ctx=null, track=null;
  function unlock(){
    try{
      const AudioCtx=window.AudioContext||window.webkitAudioContext;
      if(!ctx&&AudioCtx)ctx=new AudioCtx();
      if(ctx?.state==='suspended')ctx.resume().catch(()=>{});
    }catch(e){}
    updateMusic();
  }
  function effect(type){
    if(!sfxOn)return;
    unlock();
    if(!ctx)return;
    // Soft paired success tones and a short descending retry cue.
    const tones=type==='correct'?[{f:587,t:0,d:.13},{f:784,t:.13,d:.22}]:[{f:390,t:0,d:.16},{f:310,t:.17,d:.25}];
    const now=ctx.currentTime+.01;
    for(const n of tones){
      const osc=ctx.createOscillator(), gain=ctx.createGain();
      osc.type=type==='correct'?'sine':'triangle';osc.frequency.value=n.f;
      gain.gain.setValueAtTime(.0001,now+n.t);
      gain.gain.exponentialRampToValueAtTime(type==='correct'?.095:.065,now+n.t+.018);
      gain.gain.exponentialRampToValueAtTime(.0001,now+n.t+n.d);
      osc.connect(gain);gain.connect(ctx.destination);osc.start(now+n.t);osc.stop(now+n.t+n.d+.01);
    }
  }
  function setGameActive(v){active=!!v;updateMusic();}
  function updateMusic(){
    if(!active||!musicOn){if(track){track.pause();track=null;}return;}
    if(!track){
      track=new Audio('/assets/chill-loop.wav');track.loop=true;track.volume=.17;track.preload='auto';
    }
    if(track.paused)track.play().catch(()=>{}); // Browser gesture required; no intrusive alerts.
  }
  function setMusic(v){musicOn=!!v;save('music',musicOn);unlock();updateMusic();}
  function setSfx(v){sfxOn=!!v;save('sfx',sfxOn);}
  return {unlock,effect,setGameActive,setMusic,setSfx,musicPref:()=>musicOn,sfxPref:()=>sfxOn};
})();
