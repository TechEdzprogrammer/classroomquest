'use strict';
(() => {
  const {esc,api,toast}=window.CQ;
  let SUBJ=[];
  let area='Math',questions=[],dashboard=null,editId=null;
  let networkData={addresses:[],connectedBrowsers:0}, selectedNetwork='', connectionMode='phone';
  const $=id=>document.getElementById(id);
  const dialog=$('questionDialog');
  function tell(message,error=false){toast('teacherToast',message,error);}
  function fillSubjects(){
    for(const id of ['gameSubject','questionSubject']) {
      const select=$(id);if(!select)return;
      const previous=select.value;
      select.innerHTML=SUBJ.map(s=>`<option value="${esc(s)}">${esc(s)}</option>`).join('');
      select.value=SUBJ.includes(previous)?previous:(SUBJ.includes('Math')?'Math':SUBJ[0]);
    }
  }
  function renderManageAreas(){
    if(!$('manageSubjectList'))return;
    const counts=dashboard?.game?.bankCounts||{};
    $('manageSubjectList').innerHTML=SUBJ.map(s=>`<div class="managed-area-row"><div><strong>${esc(s)}</strong><span class="small subtle">${counts[s]||0} questions</span></div><div class="managed-area-actions"><button type="button" class="button button-soft button-small" data-rename-area="${esc(s)}">Rename</button><button type="button" class="button button-soft button-small" data-remove-area="${esc(s)}" ${SUBJ.length===1?'disabled title="Keep one area"':''}>Remove</button></div></div>`).join('');
  }
  async function syncSubjects(newSubjects){
    const previous=area;SUBJ=newSubjects;
    if(!SUBJ.includes(area))area=SUBJ.includes('Math')?'Math':SUBJ[0];
    fillSubjects();tabs();renderManageAreas();
    if($('questionList') && previous!==area) await loadQuestions();
  }
  function tabs(){
    if(!$('subjectTabs'))return;
    const counts=dashboard?.game?.bankCounts || {};
    $('subjectTabs').innerHTML=SUBJ.map(s=>`<button type="button" class="tab ${s===area?'active':''}" role="tab" aria-selected="${s===area}" data-area="${esc(s)}">${esc(s)} <span>${counts[s]||0}</span></button>`).join('');
  }
  async function loadQuestions(){
    if(!$('questionList'))return;
    try {const response=await api('/api/teacher/questions?subject='+encodeURIComponent(area));questions=response.questions;renderQuestions();}
    catch(e){tell(e.message,true);}
  }
  function renderQuestions(){
    if(!$('questionList'))return;
    $('bankLabel').textContent=area+' questions';
    $('bankTotal').textContent=questions.length+' saved multiple-choice questions';
    $('questionList').innerHTML=questions.length?questions.map((q,i)=>`<article class="question-row">
      <div><div class="question-text">${i+1}. ${esc(q.prompt)}</div><div class="question-meta">Correct answer: ${'ABCD'[q.correctIndex]} · ${esc(q.options[q.correctIndex])}</div></div>
      <div class="question-actions"><button class="icon-button" type="button" data-edit="${esc(q.id)}" title="Edit" aria-label="Edit question">✎</button><button class="icon-button danger" type="button" data-delete="${esc(q.id)}" title="Delete" aria-label="Delete question">×</button></div>
    </article>`).join(''):'<div class="empty-state">No questions saved in this learning area yet. Select “Add question” to create one.</div>';
  }
  const modeSteps={
    phone:{
      title:'Use Phone 1 as the hotspot — no router required',
      steps:['On Phone 1, turn on <b>Settings → Hotspot / Portable hotspot</b> and set a password. You may turn off mobile data if that phone still allows its hotspot to run.','On the laptop, join Phone 1’s hotspot using Windows Wi-Fi settings. Connect Phone 2 to that same hotspot.','Leave the laptop running Classroom Quest. Open the QR game link on <b>both phones</b> (including the hotspot phone).'],
      note:'Some Android hotspots prevent their own phone or other connected devices from reaching the laptop. Try it first; use another network method if the check fails.'},
    laptop:{
      title:'Use Windows Mobile Hotspot',
      steps:['On the laptop, open <b>Windows Settings → Network & Internet → Mobile hotspot</b>.','Turn the hotspot on, then connect <b>both phones</b> to its Wi-Fi name and password.','Refresh addresses below and choose the hotspot network, often starting with 192.168.137.'],
      note:'Some laptops cannot enable Mobile Hotspot without an upstream connection. If yours cannot, switch to Phone hotspot above.'},
    router:{
      title:'Use a local Wi-Fi network without internet',
      steps:['Switch on a classroom Wi-Fi router or access point. It does <b>not</b> need an internet subscription.','Connect the laptop and both phones to the <b>same</b> Wi-Fi.','Refresh addresses, choose the laptop’s Wi-Fi IP address, and open the QR link.'],
      note:'Guest networks or client isolation may block phones from reaching the laptop. Use the same trusted network, not a guest Wi-Fi.'}
  };
  function setMode(mode){
    if(!$('connectionInstructions'))return;
    connectionMode=modeSteps[mode]?mode:'phone';
    try{localStorage.setItem('cqConnectionMode',connectionMode);}catch(e){}
    for(const input of document.querySelectorAll('input[name="connectionMode"]')) input.checked=input.value===connectionMode;
    const v=modeSteps[connectionMode];
    $('connectionInstructions').innerHTML=`<div class="connect-instructions-title">${esc(v.title)}</div><ol>${v.steps.map(step=>`<li>${step}</li>`).join('')}</ol><p class="small subtle connect-caution">${esc(v.note)}</p>`;
    renderNetwork();
  }
  function chosenAddresses(){
    return (networkData.addresses||[]).slice().sort((a,b)=>{
      if(connectionMode==='laptop') return Number(b.hint==='Likely Windows hotspot')-Number(a.hint==='Likely Windows hotspot');
      return Number(b.primary)-Number(a.primary);
    });
  }
  function renderNetwork(){
    if(!$('networkCandidates'))return;
    const addresses=chosenAddresses();
    if(!addresses.some(n=>n.url===selectedNetwork)){
      selectedNetwork=addresses[0]?.url||'';
      try{localStorage.setItem('cqSelectedNetwork',selectedNetwork);}catch(e){}
    }
    $('networkCandidates').innerHTML=addresses.length ? addresses.map(n=>`<label class="network-choice ${selectedNetwork===n.url?'chosen':''}">
        <input name="networkAddress" type="radio" value="${esc(n.url)}" ${selectedNetwork===n.url?'checked':''}>
        <span><strong>${esc(n.address)}</strong><small>${esc(n.interface)} · ${esc(n.hint)}${n.primary?' · Main route':''}</small></span>
      </label>`).join(''):'<p class="subtle small">No private local IP found yet. Connect the laptop to the phone hotspot or Wi-Fi, then select “Find network addresses.”</p>';
    $('selectedPhoneUrl').textContent=selectedNetwork||'Not connected';
    $('copyPhoneUrl').disabled=!selectedNetwork;
    $('networkQR').innerHTML=selectedNetwork?`<img width="154" height="154" alt="Scan to open Classroom Quest on this phone" src="/api/teacher/qr?url=${encodeURIComponent(selectedNetwork)}">`:'<span class="subtle small">Join a local network first to generate a QR code.</span>';
    const count=Number(networkData.connectedBrowsers||0);
    const countLabel=count===0?'No student browsers detected yet':count===1?'1 student browser reached the laptop':`${count} student browsers reached the laptop`;
    $('networkCheckStatus').textContent=countLabel+'. Open the game on both phones, then select “Check phone connections”.';
    $('networkCheckStatus').className='network-check-status '+(count>=2?'check-good':count===1?'check-partial':'');
  }
  async function refreshNetworks(showMessage=false){
    const r=await api('/api/teacher/network');
    networkData=r;
    renderNetwork();
    if(showMessage){const count=r.connectedBrowsers||0;tell(count>=2?'At least two student browsers reached the game.':count===1?'One student browser connected. Check the second phone.':'The local server is running, but no student browsers have checked in yet.');}
  }
  function teamScore(team,g){return `<div class="team-score ${team==='B'?'gold':''}"><div class="team-name">${esc(g.teamNames[team])}</div><div class="points">${g.teams[team].score} <span class="small subtle">/ ${g.target}</span></div><div class="joined">${g.teams[team].occupied?'✓ Phone joined':'○ Waiting for phone'}</div></div>`;}
  function liveDetails(g){
    if(g.phase==='idle')return '<p class="subtle">No match yet. Set up a new match using the form on the right.</p>';
    let html=`<div class="live-detail">${esc(g.subject)} · First to <b>${g.target} points</b> · <b>+1</b> for every correct answer</div>
      <div class="live-scores">${teamScore('A',g)}${teamScore('B',g)}</div>`;
    if(g.phase==='lobby') html+='<div class="live-detail">Ask both teams to open the student URL and join their team. Then select <b>Begin questions</b>.</div>';
    else if(g.phase==='question'){
      html+=`<div class="live-detail">Round ${g.round} • ${g.answered.A?'✓':'○'} ${esc(g.teamNames.A)} answered • ${g.answered.B?'✓':'○'} ${esc(g.teamNames.B)} answered</div>
        <div class="live-prompt">${esc(g.question.prompt)}</div><details class="answer-reveal"><summary>Show correct answer</summary><p>Correct: <b>${'ABCD'[g.question.correctIndex]} · ${esc(g.question.options[g.question.correctIndex])}</b></p></details>`;
    } else if (g.phase==='result') {
      html+=`<div class="live-detail">Round ${g.round} completed ${g.result?.tiedAtTarget?'• Sudden-death tie-breaker needed':''}</div><div class="live-prompt">${esc(g.result.options[g.result.correctIndex])} — Correct choice ${'ABCD'[g.result.correctIndex]}</div>`;
    } else if(g.phase==='finished') html+=`<div class="live-prompt">🏆 <b>${esc(g.teamNames[g.winner])}</b> wins the match!</div>`;
    return html;
  }
  function actionButton(name,label,klass='button-soft',disabled=false){return `<button type="button" class="button ${klass}" data-action="${name}" ${disabled?'disabled':''}>${label}</button>`;}
  function renderLive(g){
    if(!$('liveMatch'))return;
    $('phasePill').textContent={idle:'No match',lobby:'Waiting for teams',question:'Live question',result:'Round complete',finished:'Winner declared'}[g.phase]||g.phase;
    $('phasePill').className='pill '+(g.phase==='question'?'live':g.phase==='finished'?'winner':'');
    $('liveMatch').innerHTML=liveDetails(g);
    let actions='';
    if(g.phase==='lobby') actions+=actionButton('begin','▶ Begin questions','button-primary',!g.teams.A.occupied||!g.teams.B.occupied);
    if(g.phase==='question') actions+=actionButton('close','Finish question now','button-primary');
    if(g.phase==='result') actions+=actionButton('next','Next question →','button-primary');
    if(g.matchId){
      actions+='<details class="extra-actions"><summary>More controls</summary><div class="extra-actions-buttons">';
      actions+=actionButton('releaseA','Release Team A phone');
      actions+=actionButton('releaseB','Release Team B phone');
      actions+=actionButton('end','End match','button-alert');
      actions+='</div></details>';
    }
    $('matchActions').innerHTML=actions;
    tabs();
  }
  let lastAudioKey='';
  function onSnapshot(g){
    dashboard=dashboard||{};dashboard.game=g;renderLive(g);
    window.CQAudio?.setGameActive(!!g.matchId && ['question','result'].includes(g.phase));
    const key=g.matchId+':'+g.round+':'+g.phase;
    if(lastAudioKey && key!==lastAudioKey && ['result','finished'].includes(g.phase)){
      const earned=g.result?.earned||{};
      window.CQAudio?.effect((earned.A||0)+(earned.B||0)>0?'correct':'wrong');
    }
    lastAudioKey=key;
  }
  async function refreshDashboard(){
    const d=await api('/api/teacher/status');dashboard=d;
    await syncSubjects(d.subjects||[]);
    renderLive(d.game);tabs();
  }
  async function perform(path,body={}){
    try {await api('/api/teacher/game/'+path,'POST',body);}
    catch(e){tell(e.message,true);}
  }
  $('matchActions')?.addEventListener('click',async e=>{
    const button=e.target.closest('[data-action]'); if(!button)return;
    const action=button.dataset.action;
    window.CQAudio?.unlock();
    if(action==='begin' && window.CQAudio?.musicPref())window.CQAudio.setGameActive(true);
    if(action==='end')window.CQAudio?.setGameActive(false);
    if(action==='end') {if(!confirm('End this match and clear the current scores?'))return;await perform('end');}
    else if(action==='releaseA'||action==='releaseB'){
      const team=action==='releaseA'?'A':'B';
      if(!confirm(`Release Team ${team}'s phone? Their score stays, but they must join again.`))return;
      await perform('release',{team});
    }
    else await perform(action);
  });
  $('newMatchForm')?.addEventListener('submit',async e=>{
    e.preventDefault();window.CQAudio?.unlock();
    if(dashboard?.game?.matchId&&!confirm('Start a new match? This will replace the current match and scores.'))return;
    const body={subject:$('gameSubject').value,target:Number($('gameTarget').value),teamA:$('gameTeamA').value,teamB:$('gameTeamB').value};
    try {await api('/api/teacher/game/new','POST',body);tell('New match created! Ask both phones to join.');}
    catch(error){tell(error.message,true);}
  });
  $('subjectTabs')?.addEventListener('click',e=>{
    const button=e.target.closest('[data-area]');if(!button)return;
    area=button.dataset.area;tabs();loadQuestions();
  });
  function openEditor(q){
    editId=q?.id||null;
    $('dialogTitle').textContent=q?'Edit question':'Add question';
    $('questionSubject').value=q?.subject||area;
    $('questionPrompt').value=q?.prompt||'';
    for(let i=0;i<4;i++) $('option'+i).value=q?.options[i]||'';
    const correctIndex=q?.correctIndex??0;
    for(const input of document.querySelectorAll('input[name="correct"]')) input.checked=Number(input.value)===correctIndex;
    dialog.showModal();$('questionPrompt').focus();
  }
  $('addQuestion')?.addEventListener('click',()=>openEditor(null));
  $('closeDialog')?.addEventListener('click',()=>dialog.close());
  $('cancelDialog')?.addEventListener('click',()=>dialog.close());
  $('questionForm')?.addEventListener('submit',async e=>{
    e.preventDefault();
    const picked=document.querySelector('input[name="correct"]:checked');
    const body={subject:$('questionSubject').value,prompt:$('questionPrompt').value,options:[0,1,2,3].map(i=>$('option'+i).value),correctIndex:Number(picked?.value??0)};
    try {
      await api(editId?'/api/teacher/questions/'+encodeURIComponent(editId):'/api/teacher/questions',editId?'PUT':'POST',body);
      dialog.close();tell(editId?'Question updated.':'Question added.');
      if(area!==body.subject)area=body.subject;
      await loadQuestions(); await refreshDashboard();
    }catch(error){tell(error.message,true);}
  });
  $('questionList')?.addEventListener('click',async e=>{
    const edit=e.target.closest('[data-edit]');
    if(edit){const q=questions.find(q=>q.id===edit.dataset.edit);if(q)openEditor(q);return;}
    const del=e.target.closest('[data-delete]');
    if(del){const q=questions.find(q=>q.id===del.dataset.delete);if(!q)return;
      if(!confirm('Delete this question? This cannot be undone unless you have a backup.'))return;
      try{await api('/api/teacher/questions/'+encodeURIComponent(q.id),'DELETE');tell('Question deleted.');await loadQuestions();await refreshDashboard();}
      catch(error){tell(error.message,true);}
    }
  });
  $('addSubjectForm')?.addEventListener('submit',async e=>{
    e.preventDefault();const name=$('subjectNameInput').value.trim();
    try {const r=await api('/api/teacher/subjects','POST',{name});$('subjectNameInput').value='';await syncSubjects(r.subjects);area=name;tabs();await loadQuestions();tell('Learning area added.');await refreshDashboard();}
    catch(error){tell(error.message,true);}
  });
  $('manageSubjectList')?.addEventListener('click',async e=>{
    const rename=e.target.closest('[data-rename-area]');const remove=e.target.closest('[data-remove-area]');
    if(rename){
      const oldName=rename.dataset.renameArea;
      const newName=prompt('New name for '+oldName+':',oldName)?.trim();
      if(!newName||newName===oldName)return;
      try{const r=await api('/api/teacher/subjects','PATCH',{oldName,name:newName});if(area===oldName)area=newName;await syncSubjects(r.subjects);await loadQuestions();await refreshDashboard();tell('Learning area renamed. Questions were kept.');}catch(error){tell(error.message,true);}return;
    }
    if(remove){
      const oldName=remove.dataset.removeArea;
      const count=dashboard?.game?.bankCounts?.[oldName]||0;
      const warning=count?'Remove "'+oldName+'" and its '+count+' questions? A safety backup will be saved on this laptop.':'Remove the empty learning area "'+oldName+'"?';
      if(!confirm(warning))return;
      try{const r=await api('/api/teacher/subjects','DELETE',{oldName,deleteQuestions:count>0});await syncSubjects(r.subjects);await refreshDashboard();await loadQuestions();tell('Learning area removed. '+(count?'A safety backup was saved.':''));}catch(error){tell(error.message,true);}
    }
  });
  $('exportBank')?.addEventListener('click',()=>{window.location.href='/api/teacher/export';});
  $('importBank')?.addEventListener('click',()=>$('importInput').click());
  $('importInput')?.addEventListener('change',async e=>{
    const file=e.target.files[0];e.target.value='';if(!file)return;
    if(!confirm('Restore this backup? All current bank questions will be REPLACED. A local safety copy is created automatically.'))return;
    try{const data=JSON.parse(await file.text());const r=await api('/api/teacher/import','POST',data);tell('Restored '+r.count+' questions successfully.');await loadQuestions();await refreshDashboard();}
    catch(error){tell(error.message,true);}
  });
  document.querySelectorAll('input[name="connectionMode"]').forEach(input=>input.addEventListener('change',()=>{selectedNetwork='';setMode(input.value);} ));
  $('networkCandidates')?.addEventListener('change',e=>{
    if(e.target.name==='networkAddress'){
      selectedNetwork=e.target.value;
      try{localStorage.setItem('cqSelectedNetwork',selectedNetwork);}catch(e){}
      renderNetwork();
    }
  });
  $('refreshNetworks')?.addEventListener('click',()=>refreshNetworks(true).catch(e=>tell(e.message,true)));
  $('checkPhones')?.addEventListener('click',()=>refreshNetworks(true).catch(e=>tell(e.message,true)));
  $('copyPhoneUrl')?.addEventListener('click',async()=>{
    if(!selectedNetwork)return;
    try{await navigator.clipboard.writeText(selectedNetwork);tell('Phone address copied.');}
    catch(e){tell('Copy this phone address: '+selectedNetwork);}
  });
  $('exitApp')?.addEventListener('click',async()=>{
    if(!confirm('Stop Classroom Quest? Both team phones will disconnect until you reopen the application.'))return;
    try{await api('/api/teacher/shutdown','POST',{});document.querySelector('main').innerHTML='<section class="card panel" style="max-width:720px;margin:40px auto;text-align:center"><h1>Classroom Quest has closed.</h1><p>You may now close this browser tab. Double-click the Classroom Quest desktop icon to play again.</p></section>';}
    catch(error){tell('Unable to stop the server: '+error.message,true);}
  });
  if($('connectionInstructions')){
    try{selectedNetwork=localStorage.getItem('cqSelectedNetwork')||'';}catch(e){}
    try{connectionMode=localStorage.getItem('cqConnectionMode')||'phone';}catch(e){}
    setMode(connectionMode);
    refreshNetworks().catch(e=>tell(e.message,true));
    setInterval(()=>refreshNetworks().catch(()=>{}),10000);
  }
  if($('musicEnabled')){
    const music=$('musicEnabled'),sfx=$('sfxEnabled');
    music.checked=window.CQAudio?.musicPref()||false;
    sfx.checked=window.CQAudio?.sfxPref()??true;
    music.addEventListener('change',()=>{window.CQAudio?.unlock();window.CQAudio?.setMusic(music.checked);});
    sfx.addEventListener('change',()=>{window.CQAudio?.unlock();window.CQAudio?.setSfx(sfx.checked);if(sfx.checked)window.CQAudio?.effect('correct');});
  }
  if($('liveMatch')||$('questionList'))refreshDashboard().then(()=>{if($('questionList'))return loadQuestions();}).catch(e=>tell(e.message,true));
  if($('liveMatch')){
    const stream=new EventSource('/api/events?role=teacher');
    stream.addEventListener('snapshot',event=>{try{onSnapshot(JSON.parse(event.data));$('teacherConnection').textContent='Server connected';}catch(e){console.error(e);}});
    stream.onerror=()=>{$('teacherConnection').textContent='Reconnecting…';};
  }
})();
