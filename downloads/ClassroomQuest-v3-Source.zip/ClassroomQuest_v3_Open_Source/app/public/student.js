'use strict';
(() => {
  const {esc,api,toast}=window.CQ;
  const content=document.getElementById('studentContent');
  const scoreboard=document.getElementById('scoreboard');
  const connection=document.getElementById('connection');
  let token=localStorage.getItem('classroomQuestDeviceToken') || '';
  let current=null;
  let stream=null;
  let sending=false;
  let priorResultKey='';

  function setConnected(yes) {
    connection.classList.toggle('offline',!yes);
    connection.innerHTML=`<span class="conn-dot"></span>${yes ? 'Live connection' : 'Reconnecting…'}`;
  }
  function scorePanel(team,g) {
    const data=g.teams[team];
    const gold=team==='B';
    const name=g.teamNames[team];
    const percent=Math.min(100,Math.round((data.score/Math.max(1,g.target))*100));
    return `<div class="score-panel ${gold?'gold':''} ${g.myTeam===team?'mine':''}">
      <div class="score-top"><span class="score-label">TEAM ${team}</span><span aria-hidden="true">${gold?'★':'✦'}</span></div>
      <div class="score-name">${esc(name)}</div>
      <div class="score-number">${data.score} <small>/ ${g.target} pts</small></div>
      <div class="progress-track" aria-label="${percent}% of target"><div class="progress-value" style="width:${percent}%"></div></div>
    </div>`;
  }
  function stage(message, title, details='') {
    return `<div class="card text-center"><div class="message-badge">${esc(message)}</div><h2 class="stage-title">${esc(title)}</h2><p class="stage-subtitle">${esc(details)}</p></div>`;
  }
  function joinScreen(g) {
    const occupiedA=g.teams.A.occupied;
    const occupiedB=g.teams.B.occupied;
    return `<div class="card"><div class="stage-kicker">CHOOSE YOUR SIDE</div><h2 class="stage-title">Join the classroom battle!</h2>
      <p class="stage-subtitle">One phone per team. Ask your teacher which team you belong to.</p>
      <div class="team-choices"><button type="button" class="team-select" data-team="A" ${occupiedA?'disabled':''}><strong>${esc(g.teamNames.A)}</strong><span>${occupiedA?'Device connected':'Tap to join • Team A'}</span></button>
      <button type="button" class="team-select gold" data-team="B" ${occupiedB?'disabled':''}><strong>${esc(g.teamNames.B)}</strong><span>${occupiedB?'Device connected':'Tap to join • Team B'}</span></button></div>
      ${occupiedA&&occupiedB?'<p class="stage-subtitle" style="margin-top:16px">Both slots are taken. Ask the teacher to release a team if this is a replacement phone.</p>':''}
    </div>`;
  }
  function waitingScreen(g) {
    const other=g.myTeam==='A'?'B':'A';
    const allReady=g.teams[other].occupied;
    return `<div class="card text-center"><div class="stage-kicker">YOU'RE IN!</div><div class="champion">${g.myTeam==='A'?'🌱':'⭐'}</div>
      <h2 class="stage-title">Welcome, ${esc(g.teamNames[g.myTeam])}!</h2><p class="stage-subtitle">${allReady?'Both teams are ready. Wait for your teacher to begin.':'Waiting for the other team to join.'}</p>
      <div class="notice">Keep this page open while your team plays. Each correct answer earns <b>1 point</b>.</div></div>`;
  }
  function questionScreen(g) {
    const done=g.submitted;
    const q=g.question;
    if (!q) return stage('GET READY','The next question is coming.');
    return `<div class="card">
      <div class="question-head"><span class="round-tag">ROUND ${g.round} · ${esc(g.subject)}</span><span class="target-tag">First to ${g.target} points</span></div>
      <h2 class="question-title">${esc(q.prompt)}</h2>
      <div class="answer-grid">${q.options.map((option,i)=>`<button class="answer-option" type="button" data-choice="${i}" ${done?'disabled':''}><span class="answer-letter">${'ABCD'[i]}</span><span>${esc(option)}</span></button>`).join('')}</div>
      <p class="stage-subtitle" style="margin:18px 0 0">${done?'✓ Answer submitted! Waiting for the other team or your teacher.':'Choose one answer together. Your choice is final.'}</p>
      </div>`;
  }
  function resultScreen(g) {
    const r=g.result;
    if (!r) return stage('ROUND COMPLETE','Well played!','Wait for your teacher to continue.');
    function answerText(choice) { return choice === null ? 'No answer' : `${'ABCD'[choice]} · ${r.options[choice]}`; }
    const tieMessage=r.tiedAtTarget ? `<div class="notice" style="margin-top:15px">It's a tie at the winning score! Play a tie-breaker round until one team takes the lead.</div>` : '';
    return `<div class="card"><div class="stage-kicker">ROUND ${g.round} COMPLETE</div><h2 class="stage-title">Check your answers!</h2>
      <div class="result-box"><div class="small subtle">CORRECT ANSWER</div><b>${'ABCD'[r.correctIndex]} · ${esc(r.options[r.correctIndex])}</b></div>
      <div class="result-row"><span>${esc(g.teamNames.A)} answered</span><span>${esc(answerText(r.answers.A))}</span></div>
      <div class="result-row"><span>${esc(g.teamNames.B)} answered</span><span>${esc(answerText(r.answers.B))}</span></div>
      <div class="result-row"><span>Points this round</span><span>+${r.earned.A} / +${r.earned.B}</span></div>
      ${tieMessage}<p class="stage-subtitle" style="margin:18px 0 0">Waiting for the teacher to continue…</p></div>`;
  }
  function winnerScreen(g) {
    const who=g.winner;
    const name=g.teamNames[who];
    const msg=g.myTeam===who?'Your team won!':`${name} won this match!`;
    return `<div class="card result-message"><div class="stage-kicker">BATTLE COMPLETE</div><div class="champion" aria-hidden="true">🏆</div>
      <h2>${esc(msg)}</h2><p class="stage-subtitle">Congratulations to both teams for learning and playing together!</p>
      <div class="notice">Final score: <b>${esc(g.teamNames.A)} ${g.teams.A.score}</b> – <b>${g.teams.B.score} ${esc(g.teamNames.B)}</b></div>
      <p class="stage-subtitle" style="margin:18px 0 0">Your teacher can start another match whenever you're ready.</p></div>`;
  }

  function render(g) {
    const key=g.matchId+':'+g.round+':'+g.phase;
    // A phone only plays feedback for its own result and never sees an unrevealed key.
    if(priorResultKey && key!==priorResultKey && (g.phase==='result'||g.phase==='finished') && g.myTeam && g.result){
      window.CQAudio?.effect((g.result.earned?.[g.myTeam]||0)>0?'correct':'wrong');
    }
    priorResultKey=key;
    current=g;
    scoreboard.innerHTML=g.matchId ? scorePanel('A',g)+scorePanel('B',g) : '';
    if (!g.matchId || g.phase==='idle') content.innerHTML=stage('WELCOME!','Your teacher is preparing a new battle.','Stay connected to your classroom local network.');
    else if (!g.myTeam) content.innerHTML=joinScreen(g);
    else if (g.phase==='lobby') content.innerHTML=waitingScreen(g);
    else if (g.phase==='question') content.innerHTML=questionScreen(g);
    else if (g.phase==='result') content.innerHTML=resultScreen(g);
    else if (g.phase==='finished') content.innerHTML=winnerScreen(g);
  }

  async function join(team) {
    if (sending) return;
    sending=true;
    try {
      const res=await api('/api/join','POST',{team,token});
      token=res.token;
      localStorage.setItem('classroomQuestDeviceToken',token);
      connect();
    } catch(e) { toast('studentToast',e.message,true); }
    finally { sending=false; }
  }
  async function submitAnswer(choice) {
    if (sending || !current || current.phase!=='question' || !current.myTeam || current.submitted) return;
    sending=true;window.CQAudio?.unlock();
    content.querySelectorAll('[data-choice]').forEach(btn => btn.disabled=true);
    try { await api('/api/answer','POST',{token,round:current.round,choice}); }
    catch(e) { toast('studentToast',e.message,true); if(current) render(current); }
    finally { sending=false; }
  }
  const soundButton=document.getElementById('toggleStudentSfx');
  if(soundButton){
    function showAudio(){const on=window.CQAudio?.sfxPref()??true;soundButton.textContent=on?'🔊 Sounds on':'🔇 Sounds off';soundButton.setAttribute('aria-pressed',String(on));}
    soundButton.addEventListener('click',()=>{window.CQAudio?.unlock();window.CQAudio?.setSfx(!window.CQAudio.sfxPref());showAudio();if(window.CQAudio.sfxPref())window.CQAudio.effect('correct');});
    showAudio();
  }
  content.addEventListener('click',e => {
    const joinButton=e.target.closest('[data-team]');
    if(joinButton) return join(joinButton.dataset.team);
    const answerButton=e.target.closest('[data-choice]');
    if(answerButton) return submitAnswer(Number(answerButton.dataset.choice));
  });
  function connect() {
    if (stream) stream.close();
    stream=new EventSource(`/api/events?token=${encodeURIComponent(token)}`);
    stream.addEventListener('snapshot',event=>{
      try { render(JSON.parse(event.data)); setConnected(true); }
      catch(e) { console.error('Invalid server update',e); }
    });
    stream.onerror=()=>setConnected(false);
  }
  // Browser check-in proves that the student page reached the laptop over the
  // actual local network; a laptop-side IP lookup alone cannot prove this.
  let browserId='';
  try{browserId=localStorage.getItem('cqStudentBrowserId')||'';}catch(e){}
  if(!/^[a-zA-Z0-9_-]{12,80}$/.test(browserId)){
    const values=new Uint32Array(4);
    if(window.crypto?.getRandomValues)window.crypto.getRandomValues(values);
    else for(let i=0;i<4;i++)values[i]=Math.floor(Math.random()*4294967296);
    browserId='phone_'+Array.from(values,x=>x.toString(16).padStart(8,'0')).join('');
    try{localStorage.setItem('cqStudentBrowserId',browserId);}catch(e){}
  }
  async function checkIn(){try{await api('/api/network/ping','POST',{clientId:browserId});}catch(e){/* Retry automatically. */}}
  // Teacher preview opened from localhost is not a remote phone connection.
  // Do not let it falsely increase the connected-phone counter.
  const localPreview=['localhost','127.0.0.1','::1'].includes(location.hostname);
  if(!localPreview){ checkIn(); setInterval(checkIn,15000); }
  connect();
})();
