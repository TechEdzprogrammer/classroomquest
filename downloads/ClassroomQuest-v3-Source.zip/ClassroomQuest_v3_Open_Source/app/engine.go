package main

import (
	"crypto/rand"
	"encoding/hex"
	"errors"
	"fmt"
	"math/big"
	"strings"
	"time"
)

var subjects = []string{"GMRC", "Makabansa", "Math", "Science", "English", "Filipino"} // migration defaults only

type Question struct {
	ID           string   `json:"id"`
	Subject      string   `json:"subject"`
	Prompt       string   `json:"prompt"`
	Options      []string `json:"options"`
	CorrectIndex int      `json:"correctIndex"`
	CreatedAt    string   `json:"createdAt,omitempty"`
	UpdatedAt    string   `json:"updatedAt,omitempty"`
}
type Team struct {
	Score int    `json:"score"`
	Token string `json:"token"`
}
type RoundResult struct {
	Question     string          `json:"question"`
	Options      []string        `json:"options"`
	CorrectIndex int             `json:"correctIndex"`
	Answers      map[string]*int `json:"answers"`
	Earned       map[string]int  `json:"earned"`
	TiedAtTarget bool            `json:"tiedAtTarget"`
}
type HistoryEntry struct {
	Round  int            `json:"round"`
	Scores map[string]int `json:"scores"`
	RoundResult
}
type Game struct {
	MatchID    string            `json:"matchId"`
	Phase      string            `json:"phase"`
	Subject    string            `json:"subject"`
	Target     int               `json:"target"`
	TeamNames  map[string]string `json:"teamNames"`
	Teams      map[string]*Team  `json:"teams"`
	Deck       []Question        `json:"deck"`
	DeckCursor int               `json:"deckCursor"`
	Round      int               `json:"round"`
	Question   *Question         `json:"question"`
	Answers    map[string]*int   `json:"answers"`
	LastResult *RoundResult      `json:"lastResult"`
	Winner     string            `json:"winner"`
	History    []HistoryEntry    `json:"history"`
}

func initialGame() Game {
	return Game{Phase: "idle", Target: 5, TeamNames: map[string]string{"A": "Team Green", "B": "Team Gold"}, Teams: map[string]*Team{"A": {}, "B": {}}, Answers: map[string]*int{"A": nil, "B": nil}, Deck: []Question{}, History: []HistoryEntry{}}
}
func guid() string {
	b := make([]byte, 16)
	if _, err := rand.Read(b); err != nil {
		panic(err)
	}
	return hex.EncodeToString(b)
}
func bad(message string) error   { return errors.New(message) }
func validSubject(s string) bool { return validSubjectIn(s, subjects) }
func validSubjectIn(s string, list []string) bool {
	for _, a := range list {
		if a == s {
			return true
		}
	}
	return false
}
func validateQuestion(q Question) (Question, error) { return validateQuestionIn(q, subjects) }
func validateQuestionIn(q Question, list []string) (Question, error) {
	if !validSubjectIn(q.Subject, list) {
		return q, bad("Choose a valid learning area.")
	}
	q.Prompt = strings.TrimSpace(q.Prompt)
	n := len([]rune(q.Prompt))
	if n < 3 || n > 500 {
		return q, bad("Question must contain 3–500 characters.")
	}
	if len(q.Options) != 4 {
		return q, bad("Each question needs exactly four choices.")
	}
	seen := map[string]bool{}
	for i, v := range q.Options {
		v = strings.TrimSpace(v)
		n := len([]rune(v))
		if n < 1 || n > 160 {
			return q, bad("Each choice needs 1–160 characters.")
		}
		q.Options[i] = v
		key := strings.ToLower(v)
		if seen[key] {
			return q, bad("All four choices must be different.")
		}
		seen[key] = true
	}
	if q.CorrectIndex < 0 || q.CorrectIndex > 3 {
		return q, bad("Choose the correct answer.")
	}
	return q, nil
}
func shuffled(items []Question) []Question {
	o := append([]Question{}, items...)
	for i := len(o) - 1; i > 0; i-- {
		n, err := rand.Int(rand.Reader, big.NewInt(int64(i+1)))
		if err != nil {
			panic(err)
		}
		j := int(n.Int64())
		o[i], o[j] = o[j], o[i]
	}
	return o
}
func (g *Game) currentTeam(token string) string {
	if token == "" || len(token) > 128 {
		return ""
	}
	for _, x := range []string{"A", "B"} {
		if g.Teams[x] != nil && g.Teams[x].Token == token {
			return x
		}
	}
	return ""
}
func (g *Game) newMatch(subject string, target int, a, b string, bank []Question) error {
	return g.newMatchIn(subject, target, a, b, bank, subjects)
}
func (g *Game) newMatchIn(subject string, target int, a, b string, bank []Question, list []string) error {
	if !validSubjectIn(subject, list) {
		return bad("Select a valid learning area.")
	}
	if target < 1 || target > 1000 {
		return bad("Winning score must be a whole number from 1 to 1000.")
	}
	a = strings.TrimSpace(a)
	b = strings.TrimSpace(b)
	if a == "" || b == "" || len([]rune(a)) > 30 || len([]rune(b)) > 30 {
		return bad("Each team name must have 1–30 characters.")
	}
	if strings.EqualFold(a, b) {
		return bad("Use different names for the two teams.")
	}
	deck := []Question{}
	for _, q := range bank {
		if q.Subject == subject {
			deck = append(deck, q)
		}
	}
	if len(deck) == 0 {
		return fmt.Errorf("Please add a %s question before creating a match.", subject)
	}
	*g = initialGame()
	g.MatchID = guid()
	g.Phase = "lobby"
	g.Subject = subject
	g.Target = target
	g.TeamNames = map[string]string{"A": a, "B": b}
	g.Deck = shuffled(deck)
	return nil
}
func (g *Game) join(team, token string) (string, error) {
	if g.MatchID == "" || g.Phase == "idle" {
		return "", bad("The teacher has not created a game.")
	}
	if team != "A" && team != "B" {
		return "", bad("Select Team A or Team B.")
	}
	if g.Teams[team].Token != "" {
		if token != "" && g.Teams[team].Token == token {
			return token, nil
		}
		return "", bad("This team is already occupied. Ask the teacher to release the device if needed.")
	}
	other := "A"
	if team == "A" {
		other = "B"
	}
	if token != "" && g.Teams[other].Token == token {
		return "", bad("This phone is already assigned to another team.")
	}
	token = guid() + guid()
	g.Teams[team].Token = token
	return token, nil
}
func (g *Game) nextQuestion() error {
	if g.Phase != "lobby" && g.Phase != "result" {
		return bad("The next question cannot be opened now.")
	}
	if g.DeckCursor >= len(g.Deck) {
		previous := ""
		if g.Question != nil {
			previous = g.Question.ID
		}
		g.Deck = shuffled(g.Deck)
		if len(g.Deck) > 1 && g.Deck[0].ID == previous {
			g.Deck[0], g.Deck[1] = g.Deck[1], g.Deck[0]
		}
		g.DeckCursor = 0
	}
	if len(g.Deck) == 0 {
		return bad("No questions available.")
	}
	q := g.Deck[g.DeckCursor]
	g.Question = &q
	g.DeckCursor++
	g.Round++
	g.Answers = map[string]*int{"A": nil, "B": nil}
	g.LastResult = nil
	g.Phase = "question"
	return nil
}
func (g *Game) begin() error {
	if g.Phase != "lobby" {
		return bad("Create a new match before starting.")
	}
	if g.Teams["A"].Token == "" || g.Teams["B"].Token == "" {
		return bad("Both teams must join before the first question.")
	}
	return g.nextQuestion()
}
func (g *Game) answer(token string, round, choice int) error {
	team := g.currentTeam(token)
	if team == "" {
		return bad("Your phone is not joined to this match. Please join again.")
	}
	if g.Phase != "question" {
		return bad("This question is closed.")
	}
	if round != g.Round {
		return bad("That question has ended. Please use the current question.")
	}
	if choice < 0 || choice > 3 {
		return bad("Select one of the four answers.")
	}
	if g.Answers[team] != nil {
		return bad("Your team has already answered.")
	}
	c := choice
	g.Answers[team] = &c
	if g.Answers["A"] != nil && g.Answers["B"] != nil {
		g.scoreRound()
	}
	return nil
}
func (g *Game) closeRound() error {
	if g.Phase != "question" {
		return bad("No open question to close.")
	}
	g.scoreRound()
	return nil
}
func (g *Game) scoreRound() {
	correct := g.Question.CorrectIndex
	earned := map[string]int{"A": 0, "B": 0}
	for _, team := range []string{"A", "B"} {
		if g.Answers[team] != nil && *g.Answers[team] == correct {
			earned[team] = 1
		}
		g.Teams[team].Score += earned[team]
	}
	tied := g.Teams["A"].Score == g.Teams["B"].Score && g.Teams["A"].Score >= g.Target
	r := &RoundResult{Question: g.Question.Prompt, Options: append([]string{}, g.Question.Options...), CorrectIndex: correct, Answers: map[string]*int{"A": g.Answers["A"], "B": g.Answers["B"]}, Earned: earned, TiedAtTarget: tied}
	g.LastResult = r
	g.History = append(g.History, HistoryEntry{Round: g.Round, Scores: map[string]int{"A": g.Teams["A"].Score, "B": g.Teams["B"].Score}, RoundResult: *r})
	if !tied && (g.Teams["A"].Score >= g.Target || g.Teams["B"].Score >= g.Target) {
		g.Winner = "A"
		if g.Teams["B"].Score > g.Teams["A"].Score {
			g.Winner = "B"
		}
		g.Phase = "finished"
	} else {
		g.Phase = "result"
	}
}
func (g *Game) resetTeam(team string) error {
	if team != "A" && team != "B" {
		return bad("Unknown team.")
	}
	if g.MatchID == "" {
		return bad("No match is active.")
	}
	g.Teams[team].Token = ""
	return nil
}
func (g *Game) publicState(token string) map[string]any {
	mine := g.currentTeam(token)
	teams := map[string]any{}
	for _, t := range []string{"A", "B"} {
		teams[t] = map[string]any{"score": g.Teams[t].Score, "occupied": g.Teams[t].Token != ""}
	}
	state := map[string]any{"matchId": nil, "phase": g.Phase, "subject": nil, "target": g.Target, "teamNames": g.TeamNames, "teams": teams, "round": g.Round, "myTeam": nil, "submitted": false, "bothSubmitted": g.Answers["A"] != nil && g.Answers["B"] != nil, "winner": nil}
	if g.MatchID != "" {
		state["matchId"] = g.MatchID
	}
	if g.Subject != "" {
		state["subject"] = g.Subject
	}
	if g.Winner != "" {
		state["winner"] = g.Winner
	}
	if mine != "" {
		state["myTeam"] = mine
		state["submitted"] = g.Answers[mine] != nil
	}
	if g.Phase == "question" && g.Question != nil {
		state["question"] = map[string]any{"id": g.Question.ID, "prompt": g.Question.Prompt, "options": g.Question.Options}
		state["answered"] = map[string]bool{"A": g.Answers["A"] != nil, "B": g.Answers["B"] != nil}
	}
	if (g.Phase == "result" || g.Phase == "finished") && g.LastResult != nil {
		state["result"] = g.LastResult
	}
	return state
}
func (g *Game) teacherState(bank []Question) map[string]any { return g.teacherStateIn(bank, subjects) }
func (g *Game) teacherStateIn(bank []Question, list []string) map[string]any {
	state := g.publicState("")
	state["answers"] = g.Answers
	state["question"] = g.Question
	h := g.History
	if len(h) > 30 {
		h = h[len(h)-30:]
	}
	state["history"] = h
	counts := map[string]int{}
	for _, s := range list {
		counts[s] = 0
	}
	for _, q := range bank {
		counts[q.Subject]++
	}
	state["bankCounts"] = counts
	return state
}
func nowISO() string { return time.Now().UTC().Format("2006-01-02T15:04:05.000Z") }
