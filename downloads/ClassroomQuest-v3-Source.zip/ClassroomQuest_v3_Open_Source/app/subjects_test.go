package main

import (
	"encoding/json"
	"net/http"
	"os"
	"path/filepath"
	"testing"
)

func TestEditableSubjectsAndSafeguardedRemoval(t *testing.T) {
	a, srv := setup(t)
	s, v := req(t, srv, "POST", "/api/teacher/subjects", map[string]any{"name": "ICT"})
	good(t, s, v)
	if !validSubjectIn("ICT", a.subjects) {
		t.Fatal("custom learning area not added")
	}
	q := map[string]any{"subject": "ICT", "prompt": "Which language runs in a browser?", "options": []string{"JavaScript", "C", "Java", "Bash"}, "correctIndex": 0}
	s, v = req(t, srv, "POST", "/api/teacher/questions", q)
	good(t, s, v)
	s, v = req(t, srv, "PATCH", "/api/teacher/subjects", map[string]any{"oldName": "ICT", "name": "Computer Education"})
	good(t, s, v)
	if a.bank[len(a.bank)-1].Subject != "Computer Education" {
		t.Fatal("question not updated with rename")
	}
	s, _ = req(t, srv, "DELETE", "/api/teacher/subjects", map[string]any{"oldName": "Computer Education"})
	if s != 409 {
		t.Fatal("unsafe removal allowed", s)
	}
	s, v = req(t, srv, "DELETE", "/api/teacher/subjects", map[string]any{"oldName": "Computer Education", "deleteQuestions": true})
	good(t, s, v)
	if validSubjectIn("Computer Education", a.subjects) {
		t.Fatal("subject still present")
	}
	if len(a.bank) != 36 {
		t.Fatal("subject questions not deleted", len(a.bank))
	}
	stored, err := createApp(a.directory)
	if err != nil {
		t.Fatal(err)
	}
	if len(stored.subjects) != 6 {
		t.Fatal("subjects did not persist")
	}
	files, err := os.ReadDir(filepath.Join(a.directory, "backups"))
	if err != nil || len(files) < 2 {
		t.Fatal("automatic safety backup missing", err)
	}
}
func TestEmptyBankAndCustomSubjectsBackupRestore(t *testing.T) {
	a, srv := setup(t)
	backup := map[string]any{"app": "Classroom Quest Offline", "version": 2, "subjects": []string{"ICT", "Robotics"}, "questions": []any{}}
	s, v := req(t, srv, "POST", "/api/teacher/import", backup)
	good(t, s, v)
	if len(a.subjects) != 2 || len(a.bank) != 0 {
		t.Fatal("empty custom backup did not load")
	}
	s, v = req(t, srv, "GET", "/api/teacher/export", nil)
	good(t, s, v)
	if int(v["version"].(float64)) != 2 {
		t.Fatal("new backup schema missing")
	}
	reopened, err := createApp(a.directory)
	if err != nil {
		t.Fatal(err)
	}
	if len(reopened.bank) != 0 || len(reopened.subjects) != 2 {
		t.Fatal("empty bank does not persist")
	}
	s, _ = req(t, srv, "POST", "/api/teacher/game/new", map[string]any{"subject": "ICT", "target": 3, "teamA": "A", "teamB": "B"})
	if s != 400 {
		t.Fatal("empty subject started match")
	}
	// v1 backup migration retains original six learning areas.
	old := map[string]any{"app": "Classroom Quest Offline", "version": 1, "questions": []any{map[string]any{"subject": "Math", "prompt": "Two plus two?", "options": []string{"1", "2", "3", "4"}, "correctIndex": 3}}}
	s, v = req(t, srv, "POST", "/api/teacher/import", old)
	good(t, s, v)
	if !validSubjectIn("Math", a.subjects) {
		t.Fatal("v1 backup restore failed")
	}
}
func TestAudioAndSubjectEditorAreOffline(t *testing.T) {
	_, srv := setup(t)
	for _, u := range []string{"/assets/chill-loop.wav", "/assets/audio.js", "/teacher/questions", "/teacher", "/"} {
		resp, err := http.Get(srv.URL + u)
		if err != nil {
			t.Fatal(err)
		}
		if resp.StatusCode != 200 {
			t.Fatal(u, resp.StatusCode)
		}
		if resp.ContentLength == 0 {
			t.Fatal("empty audio/page", u)
		}
		resp.Body.Close()
	}
}
func TestSubjectManagementProtectedFromRemoteClients(t *testing.T) {
	a, _ := setup(t)
	r, _ := http.NewRequest("GET", "http://192.168.137.1:3000/api/teacher/subjects", nil)
	r.RemoteAddr = "192.168.137.100:55555"
	rec := httptestRecorder()
	a.serve(rec, r)
	if rec.Code != 403 {
		t.Fatal("student accessed private subject API", rec.Code)
	}
}

// avoid adding dependencies in tests
func httptestRecorder() *recorder { return &recorder{header: make(http.Header)} }

type recorder struct {
	header http.Header
	Code   int
}

func (r *recorder) Header() http.Header    { return r.header }
func (r *recorder) WriteHeader(status int) { r.Code = status }
func (r *recorder) Write(b []byte) (int, error) {
	if r.Code == 0 {
		r.Code = 200
	}
	return len(b), nil
}

func TestSubjectsJSONSerializable(t *testing.T) {
	a, _ := setup(t)
	b, err := json.Marshal(a.subjects)
	if err != nil || len(b) == 0 {
		t.Fatal("subjects serialization failed")
	}
}
