module techedz/classroomquest

go 1.23
