package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func setup(t *testing.T) (*App, *httptest.Server) {
	t.Helper()
	a, err := createApp(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	srv := httptest.NewServer(http.HandlerFunc(a.serve))
	t.Cleanup(srv.Close)
	a.port = 3000
	return a, srv
}
func req(t *testing.T, srv *httptest.Server, method, path string, body any) (int, map[string]any) {
	t.Helper()
	var data io.Reader
	if body != nil {
		b, err := json.Marshal(body)
		if err != nil {
			t.Fatal(err)
		}
		data = bytes.NewBuffer(b)
	}
	r, err := http.NewRequest(method, srv.URL+path, data)
	if err != nil {
		t.Fatal(err)
	}
	if body != nil {
		r.Header.Set("Content-Type", "application/json")
	}
	res, err := http.DefaultClient.Do(r)
	if err != nil {
		t.Fatal(err)
	}
	defer res.Body.Close()
	b, err := io.ReadAll(res.Body)
	if err != nil {
		t.Fatal(err)
	}
	var v map[string]any
	if err = json.Unmarshal(b, &v); err != nil {
		t.Fatalf("bad json %s: %s", path, b)
	}
	return res.StatusCode, v
}
func good(t *testing.T, status int, body map[string]any) {
	t.Helper()
	if status < 200 || status >= 300 {
		t.Fatalf("unexpected status %d: %v", status, body)
	}
}
func TestCompleteGameAndPersistence(t *testing.T) {
	app, srv := setup(t)
	if len(app.bank) != 36 {
		t.Fatalf("expected 36 starter questions, got %d", len(app.bank))
	}
	s, v := req(t, srv, "POST", "/api/teacher/game/new", map[string]any{"subject": "Math", "target": 1, "teamA": "Grade Three", "teamB": "Scientists"})
	good(t, s, v)
	s, ja := req(t, srv, "POST", "/api/join", map[string]any{"team": "A"})
	good(t, s, ja)
	s, jb := req(t, srv, "POST", "/api/join", map[string]any{"team": "B"})
	good(t, s, jb)
	s, _ = req(t, srv, "POST", "/api/teacher/game/begin", map[string]any{})
	if s != 200 {
		t.Fatal("begin failed", s)
	}
	_, public := req(t, srv, "GET", "/api/status?token="+ja["token"].(string), nil)
	game := public["game"].(map[string]any)
	question := game["question"].(map[string]any)
	if _, leaked := question["correctIndex"]; leaked {
		t.Fatal("ANSWER KEY LEAKED to students")
	}
	if game["myTeam"] != "A" {
		t.Fatal("token did not join team A")
	}
	_, teacher := req(t, srv, "GET", "/api/teacher/status", nil)
	key := int(teacher["game"].(map[string]any)["question"].(map[string]any)["correctIndex"].(float64))
	round := int(game["round"].(float64))
	s, _ = req(t, srv, "POST", "/api/answer", map[string]any{"token": ja["token"], "round": round, "choice": key})
	if s != 200 {
		t.Fatal("A answer", s)
	}
	s, _ = req(t, srv, "POST", "/api/answer", map[string]any{"token": jb["token"], "round": round, "choice": (key + 1) % 4})
	if s != 200 {
		t.Fatal("B answer", s)
	}
	_, after := req(t, srv, "GET", "/api/status", nil)
	ag := after["game"].(map[string]any)
	if ag["phase"] != "finished" || ag["winner"] != "A" {
		t.Fatalf("unexpected winner result: %v", ag)
	}
	scores := ag["teams"].(map[string]any)
	if scores["A"].(map[string]any)["score"].(float64) != 1 || scores["B"].(map[string]any)["score"].(float64) != 0 {
		t.Fatal("must award exactly 1 point")
	}
	_, err := createApp(app.directory)
	if err != nil {
		t.Fatal("reopening should preserve game", err)
	}
	if _, err := os.Stat(filepath.Join(app.directory, "game-state.json")); err != nil {
		t.Fatal("game persistence missing")
	}
}
func TestEditingImportBackupAndValidation(t *testing.T) {
	app, srv := setup(t)
	payload := map[string]any{"subject": "Filipino", "prompt": "Ano ang kulay ng dahon?", "options": []string{"Berde", "Asul", "Dilaw", "Pula"}, "correctIndex": 0}
	s, v := req(t, srv, "POST", "/api/teacher/questions", payload)
	good(t, s, v)
	id := v["question"].(map[string]any)["id"].(string)
	_, list := req(t, srv, "GET", "/api/teacher/questions?subject=Filipino", nil)
	if len(list["questions"].([]any)) != 7 {
		t.Fatal("expected 7 Filipino questions")
	}
	s, _ = req(t, srv, "DELETE", "/api/teacher/questions/"+id, nil)
	if s != 200 {
		t.Fatal("delete failed", s)
	}
	_, backup := req(t, srv, "GET", "/api/teacher/export", nil)
	s, v = req(t, srv, "POST", "/api/teacher/import", backup)
	good(t, s, v)
	if int(v["count"].(float64)) != 36 {
		t.Fatal("backup restore count mismatch")
	}
	files, _ := os.ReadDir(filepath.Join(app.directory, "backups"))
	if len(files) != 1 {
		t.Fatal("safety backup missing")
	}
	s, _ = req(t, srv, "POST", "/api/teacher/game/new", map[string]any{"subject": "Science", "target": 0, "teamA": "A", "teamB": "B"})
	if s != 400 {
		t.Fatal("zero target accepted")
	}
}
func TestOriginStudentRestrictionsAndOfflineAssets(t *testing.T) {
	app, srv := setup(t)
	_ = app
	for _, p := range []string{"/", "/teacher", "/teacher/questions", "/instructions", "/assets/styles.css", "/assets/student.js", "/assets/teacher.js"} {
		r, err := http.Get(srv.URL + p)
		if err != nil {
			t.Fatal(err)
		}
		b, _ := io.ReadAll(r.Body)
		r.Body.Close()
		if r.StatusCode != 200 || len(b) < 50 {
			t.Fatal("missing embedded asset", p)
		}
	}
	reqBody := strings.NewReader(`{}`)
	r, _ := http.NewRequest("POST", srv.URL+"/api/teacher/game/end", reqBody)
	r.Header.Set("Origin", "http://malicious.example")
	r.Header.Set("Content-Type", "application/json")
	res, err := http.DefaultClient.Do(r)
	if err != nil {
		t.Fatal(err)
	}
	res.Body.Close()
	if res.StatusCode != 403 {
		t.Fatal("CSRF origin accepted", res.StatusCode)
	}
	// Simulate a smartphone with a private LAN host and address even though test request originated from loopback.
	u, err := http.NewRequest("GET", fmt.Sprintf("http://192.168.137.1:%d/teacher", app.port), nil)
	if err != nil {
		t.Fatal(err)
	}
	u.RemoteAddr = "192.168.137.100:54321"
	rec := httptest.NewRecorder()
	app.serve(rec, u)
	if rec.Code != 403 {
		t.Fatalf("phone could load teacher: %d", rec.Code)
	}
	for _, path := range []string{"/teacher/questions", "/instructions", "/api/teacher/questions"} {
		u.URL.Path = path
		rec = httptest.NewRecorder()
		app.serve(rec, u)
		if rec.Code != 403 {
			t.Fatalf("phone could read private teacher page %s: %d", path, rec.Code)
		}
	}
}
func TestTieBreaker(t *testing.T) {
	a, srv := setup(t)
	s, _ := req(t, srv, "POST", "/api/teacher/game/new", map[string]any{"subject": "Math", "target": 1, "teamA": "A", "teamB": "B"})
	if s != 200 {
		t.Fatal(s)
	}
	_, ja := req(t, srv, "POST", "/api/join", map[string]any{"team": "A"})
	_, jb := req(t, srv, "POST", "/api/join", map[string]any{"team": "B"})
	_, _ = req(t, srv, "POST", "/api/teacher/game/begin", map[string]any{})
	// Correct for both => tie at target; next round => either team can win the sudden death.
	_, teacher := req(t, srv, "GET", "/api/teacher/status", nil)
	correct := int(teacher["game"].(map[string]any)["question"].(map[string]any)["correctIndex"].(float64))
	for _, j := range []map[string]any{ja, jb} {
		s, _ = req(t, srv, "POST", "/api/answer", map[string]any{"token": j["token"], "round": 1, "choice": correct})
		if s != 200 {
			t.Fatal("failed answer")
		}
	}
	if a.game.Phase != "result" || !a.game.LastResult.TiedAtTarget {
		t.Fatal("tie breaker missing")
	}
	s, _ = req(t, srv, "POST", "/api/teacher/game/next", map[string]any{})
	if s != 200 {
		t.Fatal("next")
	}
	_, teacher = req(t, srv, "GET", "/api/teacher/status", nil)
	correct = int(teacher["game"].(map[string]any)["question"].(map[string]any)["correctIndex"].(float64))
	_, _ = req(t, srv, "POST", "/api/answer", map[string]any{"token": ja["token"], "round": 2, "choice": (correct + 1) % 4})
	_, _ = req(t, srv, "POST", "/api/answer", map[string]any{"token": jb["token"], "round": 2, "choice": correct})
	if a.game.Phase != "finished" || a.game.Winner != "B" {
		t.Fatal("failed to resolve tie")
	}
}
