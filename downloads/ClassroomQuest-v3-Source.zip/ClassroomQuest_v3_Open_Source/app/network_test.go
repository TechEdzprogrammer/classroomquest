package main

import (
	"net"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"
)

func TestNetworkCheckinsAndTeacherPrivacy(t *testing.T) {
	app, srv := setup(t)
	s, _ := req(t, srv, "POST", "/api/network/ping", map[string]any{"clientId": "phone_browser_001"})
	if s != 200 {
		t.Fatalf("phone ping refused: %d", s)
	}
	s, _ = req(t, srv, "POST", "/api/network/ping", map[string]any{"clientId": "phone_browser_002"})
	if s != 200 {
		t.Fatalf("phone 2 ping refused: %d", s)
	}
	_, result := req(t, srv, "GET", "/api/teacher/network", nil)
	if result["connectedBrowsers"].(float64) != 2 {
		t.Fatalf("expected 2 student browsers: %v", result)
	}
	s, _ = req(t, srv, "POST", "/api/network/ping", map[string]any{"clientId": "phone_browser_001"})
	if s != 200 {
		t.Fatal("repeat ping failed")
	}
	_, result = req(t, srv, "GET", "/api/teacher/network", nil)
	if result["connectedBrowsers"].(float64) != 2 {
		t.Fatal("duplicate device counted twice")
	}
	for _, invalid := range []string{"", "x", "../other", "contains spaces"} {
		s, _ = req(t, srv, "POST", "/api/network/ping", map[string]any{"clientId": invalid})
		if s != 400 {
			t.Fatalf("invalid id %q accepted", invalid)
		}
	}
	// Stale check-ins must not be presented as live connections.
	app.mu.Lock()
	app.clients["phone_browser_001"] = time.Now().Add(-2 * liveClientWindow)
	app.mu.Unlock()
	_, result = req(t, srv, "GET", "/api/teacher/network", nil)
	if result["connectedBrowsers"].(float64) != 1 {
		t.Fatalf("stale device not expired: %v", result)
	}
	remote, _ := http.NewRequest("GET", "http://192.168.43.100:3000/api/teacher/network", nil)
	remote.RemoteAddr = "192.168.43.21:54321"
	rec := httptest.NewRecorder()
	app.serve(rec, remote)
	if rec.Code != 403 {
		t.Fatal("student accessed teacher network details")
	}
}
func TestChoiceRanksAndValidation(t *testing.T) {
	for _, tc := range []struct{ name, ip, hint string }{
		{"Wi-Fi", "192.168.43.2", "Wi-Fi network"},
		{"Local Area Connection* 1", "192.168.137.1", "Likely Windows hotspot"},
		{"vEthernet (WSL)", "172.20.0.1", "Virtual or VPN adapter — may not work on phones"},
	} {
		if h := addressHint(tc.name, net.ParseIP(tc.ip)); h != tc.hint {
			t.Errorf("%v: %s != %s", tc, h, tc.hint)
		}
	}
	win := NetworkChoice{Hint: "Likely Windows hotspot"}
	wifi := NetworkChoice{Hint: "Wi-Fi network", Primary: true}
	virtual := NetworkChoice{Hint: "Virtual or VPN adapter — may not work on phones"}
	if rankChoice(wifi) <= rankChoice(win) || rankChoice(win) <= rankChoice(virtual) {
		t.Fatal("undesirable network ranking")
	}
	for _, id := range []string{"phone_browser_1", "abcdef123456", "ABC_12-xyz_98"} {
		if !validClientID(id) {
			t.Fatal("valid client ID rejected", id)
		}
	}
}
