package main

import (
	"os"
	"strings"
	"testing"
)

func TestQRGenerator(t *testing.T) {
	for _, url := range []string{"http://192.168.137.1:3000", "http://10.0.0.1:3010", "http://172.16.100.254:3008"} {
		s, err := qrSVG(url)
		if err != nil {
			t.Fatal(err)
		}
		if !strings.Contains(s, "<svg") || !strings.Contains(s, "</svg>") {
			t.Fatal("Invalid QR SVG")
		}
	}
	s, err := qrSVG("http://192.168.137.1:3000")
	if err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile("/tmp/cq-qr-check.svg", []byte(s), 0644); err != nil {
		t.Fatal(err)
	}
}
