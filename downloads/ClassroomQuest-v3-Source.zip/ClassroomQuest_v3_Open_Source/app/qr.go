package main

// QR Code generator for short local HTTP URLs.
// Fixed QR version 3 (29x29), byte mode, low ECC (15 Reed-Solomon symbols),
// mask 0. Works completely offline without dependencies.
import (
	"errors"
	"fmt"
	"strings"
)

const qrSize = 29

type qrGrid struct {
	cells    [qrSize][qrSize]bool
	reserved [qrSize][qrSize]bool
}

func (q *qrGrid) mod(x, y int, dark bool) {
	if x >= 0 && y >= 0 && x < qrSize && y < qrSize {
		q.cells[y][x] = dark
		q.reserved[y][x] = true
	}
}
func gfMultiply(x, y byte) byte {
	var z byte
	for i := 7; i >= 0; i-- {
		z = byte((int(z) << 1) ^ ((int(z) >> 7) * 0x1d))
		z ^= byte(((int(y) >> i) & 1) * int(x))
	}
	return z
}
func encodeQR3(s string) ([]byte, error) {
	input := []byte(s)
	if len(input) > 53 {
		return nil, errors.New("QR address is too long")
	}
	bits := make([]bool, 0, 440)
	appendBits := func(value int, n int) {
		for i := n - 1; i >= 0; i-- {
			bits = append(bits, (value>>i)&1 == 1)
		}
	}
	appendBits(4, 4)
	appendBits(len(input), 8)
	for _, b := range input {
		appendBits(int(b), 8)
	}
	for i := 0; i < 4 && len(bits) < 55*8; i++ {
		bits = append(bits, false)
	}
	for len(bits)%8 != 0 {
		bits = append(bits, false)
	}
	data := make([]byte, 0, 55)
	for i := 0; i < len(bits); i += 8 {
		var v byte
		for _, b := range bits[i : i+8] {
			v <<= 1
			if b {
				v |= 1
			}
		}
		data = append(data, v)
	}
	for len(data) < 55 {
		if len(data)%2 == 0 {
			data = append(data, 0xec)
		} else {
			data = append(data, 0x11)
		}
	}
	// Reed-Solomon divisor polynomial (x + alpha^i), with primitive 0x11D.
	poly := []byte{1}
	alpha := byte(1)
	for i := 0; i < 15; i++ {
		next := make([]byte, len(poly)+1)
		for j, v := range poly {
			next[j] ^= v
			next[j+1] ^= gfMultiply(v, alpha)
		}
		poly = next
		alpha = gfMultiply(alpha, 2)
	}
	work := make([]byte, 70)
	copy(work, data)
	for i := 0; i < len(data); i++ {
		coef := work[i]
		for j, p := range poly {
			work[i+j] ^= gfMultiply(coef, p)
		}
	}
	return append(data, work[55:]...), nil
}
func (q *qrGrid) finder(cx, cy int) {
	for dy := -4; dy <= 4; dy++ {
		for dx := -4; dx <= 4; dx++ {
			r := abs(dx)
			if abs(dy) > r {
				r = abs(dy)
			}
			q.mod(cx+dx, cy+dy, r != 2 && r != 4)
		}
	}
}
func abs(x int) int {
	if x < 0 {
		return -x
	}
	return x
}
func (q *qrGrid) alignment(cx, cy int) {
	for dy := -2; dy <= 2; dy++ {
		for dx := -2; dx <= 2; dx++ {
			r := abs(dx)
			if abs(dy) > r {
				r = abs(dy)
			}
			q.mod(cx+dx, cy+dy, r != 1)
		}
	}
}
func (q *qrGrid) format(mask int) {
	data := (1 << 3) | mask
	rem := data
	for i := 0; i < 10; i++ {
		rem = (rem << 1) ^ ((rem >> 9) * 0x537)
	}
	value := ((data << 10) | rem) ^ 0x5412
	bit := func(i int) bool { return ((value >> i) & 1) != 0 }
	for i := 0; i <= 5; i++ {
		q.mod(8, i, bit(i))
	}
	q.mod(8, 7, bit(6))
	q.mod(8, 8, bit(7))
	q.mod(7, 8, bit(8))
	for i := 9; i < 15; i++ {
		q.mod(14-i, 8, bit(i))
	}
	for i := 0; i < 8; i++ {
		q.mod(qrSize-1-i, 8, bit(i))
	}
	for i := 8; i < 15; i++ {
		q.mod(8, qrSize-15+i, bit(i))
	}
	q.mod(8, qrSize-8, true)
}
func qrSVG(value string) (string, error) {
	for _, r := range value {
		if r < 32 || r > 126 {
			return "", errors.New("QR code only supports short ASCII addresses")
		}
	}
	words, err := encodeQR3(value)
	if err != nil {
		return "", err
	}
	var q qrGrid
	for i := 8; i < qrSize-8; i++ {
		q.mod(6, i, i%2 == 0)
		q.mod(i, 6, i%2 == 0)
	}
	q.finder(3, 3)
	q.finder(qrSize-4, 3)
	q.finder(3, qrSize-4)
	q.alignment(22, 22)
	q.format(0)
	bits := make([]bool, 0, len(words)*8)
	for _, b := range words {
		for i := 7; i >= 0; i-- {
			bits = append(bits, (int(b)>>i)&1 == 1)
		}
	}
	index := 0
	for right := qrSize - 1; right >= 1; right -= 2 {
		if right == 6 {
			right = 5
		}
		upwards := ((right + 1) & 2) == 0
		for vertical := 0; vertical < qrSize; vertical++ {
			y := vertical
			if upwards {
				y = qrSize - 1 - vertical
			}
			for j := 0; j < 2; j++ {
				x := right - j
				if q.reserved[y][x] {
					continue
				}
				v := index < len(bits) && bits[index]
				index++
				q.cells[y][x] = v != ((x+y)%2 == 0)
			}
		}
	}
	if index < len(bits) {
		return "", fmt.Errorf("QR data overflow: %d of %d bits", index, len(bits))
	}
	var sb strings.Builder
	sb.WriteString(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 37 37" shape-rendering="crispEdges" role="img" aria-label="Scan with phone camera to join quiz"><rect width="37" height="37" fill="#fffdf5"/><path fill="#155438" d="`)
	for y := 0; y < qrSize; y++ {
		for x := 0; x < qrSize; x++ {
			if q.cells[y][x] {
				fmt.Fprintf(&sb, "M%d %dh1v1h-1z", x+4, y+4)
			}
		}
	}
	sb.WriteString(`"/></svg>`)
	return sb.String(), nil
}
