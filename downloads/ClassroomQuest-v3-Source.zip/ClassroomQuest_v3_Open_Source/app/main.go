package main

import (
	"crypto/subtle"
	"embed"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"io/fs"
	"log"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"sync"
	"time"
)

//go:embed public/* seed/question-bank.json
var assets embed.FS

const appVersion = "3.0.0"

type App struct {
	mu        sync.RWMutex
	bank      []Question
	subjects  []string
	game      Game
	directory string
	port      int
	watchers  map[chan struct{}]struct{}
	clients   map[string]time.Time
	shutdown  func()
}

func saveJSON(filename string, obj any) error {
	bytes, err := json.MarshalIndent(obj, "", "  ")
	if err != nil {
		return err
	}
	tmp := filename + "." + guid() + ".tmp"
	if err = os.WriteFile(tmp, append(bytes, '\n'), 0600); err != nil {
		return err
	}
	if err = os.Rename(tmp, filename); err != nil {
		_ = os.Remove(filename)
		if retry := os.Rename(tmp, filename); retry != nil {
			_ = os.Remove(tmp)
			return retry
		}
	}
	return nil
}
func appDataPath() string {
	if runtime.GOOS == "windows" {
		return filepath.Join(os.Getenv("LOCALAPPDATA"), "TechEdz", "Classroom Quest Offline", "data")
	}
	dir, _ := os.UserConfigDir()
	if dir == "" {
		dir = os.TempDir()
	}
	return filepath.Join(dir, "TechEdz", "Classroom Quest Offline", "data")
}
func createApp(dir string) (*App, error) {
	if err := os.MkdirAll(dir, 0700); err != nil {
		return nil, err
	}
	a := &App{directory: dir, game: initialGame(), watchers: make(map[chan struct{}]struct{}), clients: make(map[string]time.Time)}
	file := filepath.Join(dir, "question-bank.json")
	b, err := os.ReadFile(file)
	if errors.Is(err, os.ErrNotExist) {
		b, err = assets.ReadFile("seed/question-bank.json")
		if err == nil {
			err = saveJSON(file, json.RawMessage(b))
		}
	}
	if err != nil {
		return nil, err
	}
	if err = json.Unmarshal(b, &a.bank); err != nil {
		return nil, fmt.Errorf("question-bank.json is invalid: %w", err)
	}
	// The subject list is persisted separately and can be changed by teachers.
	// When upgrading from v2.2, preserve every existing question and subject.
	subjectFile := filepath.Join(dir, "subjects.json")
	if data, readErr := os.ReadFile(subjectFile); readErr == nil {
		if err := json.Unmarshal(data, &a.subjects); err != nil {
			return nil, fmt.Errorf("subjects.json is invalid: %w", err)
		}
	} else if errors.Is(readErr, os.ErrNotExist) {
		a.subjects = append([]string{}, subjects...)
		for _, q := range a.bank {
			if !validSubjectIn(q.Subject, a.subjects) {
				a.subjects = append(a.subjects, q.Subject)
			}
		}
		if err := saveJSON(subjectFile, a.subjects); err != nil {
			return nil, err
		}
	} else {
		return nil, readErr
	}
	if err := validateSubjects(a.subjects); err != nil {
		return nil, fmt.Errorf("Learning areas: %w", err)
	}
	for _, q := range a.bank {
		if _, err = validateQuestionIn(q, a.subjects); err != nil {
			return nil, fmt.Errorf("Question bank contains invalid questions: %w", err)
		}
	}
	if b, err = os.ReadFile(filepath.Join(dir, "game-state.json")); err == nil {
		if err = json.Unmarshal(b, &a.game); err != nil {
			return nil, fmt.Errorf("game-state.json is invalid: %w", err)
		}
	} else if !errors.Is(err, os.ErrNotExist) {
		return nil, err
	}
	if a.game.Teams == nil || a.game.Answers == nil || a.game.TeamNames == nil {
		a.game = initialGame()
	}
	return a, nil
}
func (a *App) persist() {
	if err := saveJSON(filepath.Join(a.directory, "game-state.json"), a.game); err != nil {
		log.Printf("Could not save game: %v", err)
	}
	a.changed()
}
func (a *App) changed() {
	for c := range a.watchers {
		select {
		case c <- struct{}{}:
		default:
		}
	}
}
func validateSubjectName(name string) error {
	name = strings.TrimSpace(name)
	n := len([]rune(name))
	if n < 2 || n > 45 {
		return bad("Learning area must contain 2–45 characters.")
	}
	for _, c := range name {
		if c < 32 || c == 127 {
			return bad("Learning area contains unsupported characters.")
		}
	}
	return nil
}
func validateSubjects(list []string) error {
	if len(list) < 1 || len(list) > 40 {
		return bad("Choose 1–40 learning areas.")
	}
	seen := map[string]bool{}
	for _, name := range list {
		if err := validateSubjectName(name); err != nil {
			return err
		}
		if name != strings.TrimSpace(name) || seen[strings.ToLower(name)] {
			return bad("Duplicate or invalid learning areas.")
		}
		seen[strings.ToLower(name)] = true
	}
	return nil
}
func (a *App) backupBank() error {
	dir := filepath.Join(a.directory, "backups")
	if err := os.MkdirAll(dir, 0700); err != nil {
		return err
	}
	return saveJSON(filepath.Join(dir, fmt.Sprintf("question-bank-%d.json", time.Now().UnixNano())), map[string]any{"app": "Classroom Quest Offline", "version": 2, "subjects": a.subjects, "questions": a.bank})
}
func (a *App) saveSubjects() error {
	return saveJSON(filepath.Join(a.directory, "subjects.json"), a.subjects)
}
func (a *App) saveBank() error {
	return saveJSON(filepath.Join(a.directory, "question-bank.json"), a.bank)
}
func send(w http.ResponseWriter, status int, data any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(data)
}
func fail(w http.ResponseWriter, status int, err error) {
	send(w, status, map[string]string{"error": err.Error()})
}
func jsonBody(r *http.Request, dest any) error {
	if !strings.HasPrefix(r.Header.Get("Content-Type"), "application/json") {
		return bad("JSON content type required.")
	}
	d := json.NewDecoder(io.LimitReader(r.Body, 750001))
	d.DisallowUnknownFields()
	if err := d.Decode(dest); err != nil {
		return bad("Invalid JSON request.")
	}
	if d.Decode(new(any)) != io.EOF {
		return bad("Invalid JSON request.")
	}
	return nil
}
func remoteLocal(r *http.Request) bool {
	h, _, err := net.SplitHostPort(r.RemoteAddr)
	if err != nil {
		return false
	}
	return net.ParseIP(h) != nil && net.ParseIP(h).IsLoopback()
}
func allowedHost(r *http.Request) bool {
	host, _, err := net.SplitHostPort(r.Host)
	if err != nil {
		return false
	}
	if strings.EqualFold(host, "localhost") {
		return true
	}
	ip := net.ParseIP(host)
	if ip == nil {
		return false
	}
	return ip.IsLoopback() || ip.IsPrivate() || ip.IsLinkLocalUnicast()
}
func localTeacher(r *http.Request) bool {
	if !remoteLocal(r) {
		return false
	}
	host, _, err := net.SplitHostPort(r.Host)
	if err != nil {
		return false
	}
	return strings.EqualFold(host, "localhost") || (net.ParseIP(host) != nil && net.ParseIP(host).IsLoopback())
}
func (a *App) serve(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("X-Content-Type-Options", "nosniff")
	w.Header().Set("X-Frame-Options", "DENY")
	w.Header().Set("Referrer-Policy", "no-referrer")
	w.Header().Set("Cache-Control", "no-store")
	w.Header().Set("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'")
	if !allowedHost(r) {
		fail(w, 403, bad("This network address is not permitted."))
		return
	}
	p := r.URL.Path
	local := localTeacher(r)
	if r.Method == "GET" && p == "/api/teacher/qr" {
		if !local {
			fail(w, 403, bad("Teacher only."))
			return
		}
		url := r.URL.Query().Get("url")
		if !strings.HasPrefix(url, "http://") || len(url) > 53 {
			fail(w, 400, bad("Invalid local QR address."))
			return
		}
		parsed, err := http.NewRequest("GET", url, nil)
		if err != nil || !allowedHost(parsed) {
			fail(w, 400, bad("Only local addresses may be shown."))
			return
		}
		svg, err := qrSVG(url)
		if err != nil {
			fail(w, 400, err)
			return
		}
		w.Header().Set("Content-Type", "image/svg+xml; charset=utf-8")
		_, _ = io.WriteString(w, svg)
		return
	}
	if r.Method != "GET" && r.Method != "HEAD" {
		origin := r.Header.Get("Origin")
		if origin != "" && origin != "http://"+r.Host {
			fail(w, 403, bad("Cross-origin requests are not allowed."))
			return
		}
		if (r.Method == "POST" || r.Method == "PUT" || r.Method == "PATCH") && !strings.HasPrefix(r.Header.Get("Content-Type"), "application/json") {
			fail(w, 415, bad("JSON content type required."))
			return
		}
	}
	if (p == "/teacher" || p == "/teacher/questions" || p == "/instructions" || strings.HasPrefix(p, "/api/teacher/")) && !local {
		fail(w, 403, bad("Teacher controls are available only from the hosting laptop via localhost."))
		return
	}
	pages := map[string]struct{ file, ct string }{"/": {"public/student.html", "text/html; charset=utf-8"}, "/teacher": {"public/teacher.html", "text/html; charset=utf-8"}, "/teacher/questions": {"public/bank.html", "text/html; charset=utf-8"}, "/instructions": {"public/instructions.html", "text/html; charset=utf-8"}, "/assets/styles.css": {"public/styles.css", "text/css; charset=utf-8"}, "/assets/student.js": {"public/student.js", "text/javascript; charset=utf-8"}, "/assets/teacher.js": {"public/teacher.js", "text/javascript; charset=utf-8"}, "/assets/audio.js": {"public/audio.js", "text/javascript; charset=utf-8"}, "/assets/chill-loop.wav": {"public/chill-loop.wav", "audio/wav"}, "/assets/common.js": {"public/common.js", "text/javascript; charset=utf-8"}, "/assets/icon.svg": {"public/icon.svg", "image/svg+xml"}}
	if page, ok := pages[p]; ok && r.Method == "GET" {
		b, err := fs.ReadFile(assets, page.file)
		if err != nil {
			fail(w, 500, bad("Cannot load interface."))
			return
		}
		w.Header().Set("Content-Type", page.ct)
		w.WriteHeader(200)
		_, _ = w.Write(b)
		return
	}
	if p == "/api/events" && r.Method == "GET" {
		if r.URL.Query().Get("role") == "teacher" && !local {
			fail(w, 403, bad("Teacher stream is private."))
			return
		}
		a.events(w, r)
		return
	}
	a.mu.Lock()
	defer a.mu.Unlock()
	switch {
	case r.Method == "GET" && p == "/api/status":
		send(w, 200, map[string]any{"game": a.game.publicState(r.URL.Query().Get("token"))})
		return
	case r.Method == "POST" && p == "/api/join":
		var b struct {
			Team  string `json:"team"`
			Token string `json:"token"`
		}
		if err := jsonBody(r, &b); err != nil {
			fail(w, 400, err)
			return
		}
		token, err := a.game.join(b.Team, b.Token)
		if err != nil {
			fail(w, 409, err)
			return
		}
		a.persist()
		send(w, 200, map[string]string{"token": token, "team": b.Team})
		return
	case r.Method == "POST" && p == "/api/answer":
		var b struct {
			Token  string `json:"token"`
			Round  int    `json:"round"`
			Choice int    `json:"choice"`
		}
		if err := jsonBody(r, &b); err != nil {
			fail(w, 400, err)
			return
		}
		if err := a.game.answer(b.Token, b.Round, b.Choice); err != nil {
			fail(w, 409, err)
			return
		}
		a.persist()
		send(w, 200, map[string]bool{"ok": true})
		return
	case r.Method == "POST" && p == "/api/network/ping":
		var body struct {
			ClientID string `json:"clientId"`
		}
		if err := jsonBody(r, &body); err != nil {
			fail(w, 400, err)
			return
		}
		if !validClientID(body.ClientID) {
			fail(w, 400, bad("Invalid device check-in."))
			return
		}
		a.noteStudentBrowser(body.ClientID)
		send(w, 200, map[string]any{"ok": true})
		return
	case r.Method == "GET" && p == "/api/teacher/network":
		send(w, 200, map[string]any{"addresses": networkChoices(a.port), "connectedBrowsers": a.activeStudentBrowsers(), "windowSeconds": int(liveClientWindow.Seconds())})
		return
	case p == "/api/teacher/subjects" && r.Method == "GET":
		send(w, 200, map[string]any{"subjects": a.subjects})
		return
	case p == "/api/teacher/subjects" && (r.Method == "POST" || r.Method == "PATCH" || r.Method == "DELETE"):
		var b struct {
			Name            string `json:"name"`
			OldName         string `json:"oldName"`
			DeleteQuestions bool   `json:"deleteQuestions"`
		}
		if err := jsonBody(r, &b); err != nil {
			fail(w, 400, err)
			return
		}
		name := strings.TrimSpace(b.Name)
		old := strings.TrimSpace(b.OldName)
		if r.Method == "POST" {
			if len(a.subjects) >= 40 {
				fail(w, 400, bad("Maximum 40 learning areas."))
				return
			}
			if err := validateSubjectName(name); err != nil {
				fail(w, 400, err)
				return
			}
			for _, s := range a.subjects {
				if strings.EqualFold(s, name) {
					fail(w, 409, bad("This learning area already exists."))
					return
				}
			}
			a.subjects = append(a.subjects, name)
		} else {
			idx := -1
			for i, s := range a.subjects {
				if s == old {
					idx = i
					break
				}
			}
			if idx < 0 {
				fail(w, 404, bad("Learning area not found."))
				return
			}
			if a.game.MatchID != "" && a.game.Subject == old {
				fail(w, 409, bad("End the current match before changing its learning area."))
				return
			}
			if r.Method == "PATCH" {
				if err := validateSubjectName(name); err != nil {
					fail(w, 400, err)
					return
				}
				for _, s := range a.subjects {
					if s != old && strings.EqualFold(s, name) {
						fail(w, 409, bad("This learning area already exists."))
						return
					}
				}
				// Back up before changing any subject assigned to questions.
				if err := a.backupBank(); err != nil {
					fail(w, 500, err)
					return
				}
				for i := range a.bank {
					if a.bank[i].Subject == old {
						a.bank[i].Subject = name
					}
				}
				a.subjects[idx] = name
				if err := a.saveBank(); err != nil {
					fail(w, 500, err)
					return
				}
			} else {
				if len(a.subjects) <= 1 {
					fail(w, 409, bad("Keep at least one learning area."))
					return
				}
				count := 0
				for _, q := range a.bank {
					if q.Subject == old {
						count++
					}
				}
				if count > 0 && !b.DeleteQuestions {
					fail(w, 409, bad("This learning area contains questions. Explicitly confirm removal of its questions to continue."))
					return
				}
				if count > 0 {
					if err := a.backupBank(); err != nil {
						fail(w, 500, err)
						return
					}
					kept := make([]Question, 0, len(a.bank)-count)
					for _, q := range a.bank {
						if q.Subject != old {
							kept = append(kept, q)
						}
					}
					a.bank = kept
					if err := a.saveBank(); err != nil {
						fail(w, 500, err)
						return
					}
				}
				a.subjects = append(a.subjects[:idx], a.subjects[idx+1:]...)
			}
		}
		if err := a.saveSubjects(); err != nil {
			fail(w, 500, err)
			return
		}
		a.changed()
		send(w, 200, map[string]any{"subjects": a.subjects})
		return
	case r.Method == "GET" && p == "/api/teacher/status":
		send(w, 200, map[string]any{"game": a.game.teacherStateIn(a.bank, a.subjects), "networkAddresses": networkChoices(a.port), "subjects": a.subjects})
		return
	case r.Method == "GET" && p == "/api/teacher/questions":
		subject := r.URL.Query().Get("subject")
		if !validSubjectIn(subject, a.subjects) {
			fail(w, 400, bad("Invalid learning area."))
			return
		}
		questions := []Question{}
		for _, q := range a.bank {
			if q.Subject == subject {
				questions = append(questions, q)
			}
		}
		send(w, 200, map[string]any{"questions": questions})
		return
	case r.Method == "POST" && p == "/api/teacher/questions":
		var q Question
		if err := jsonBody(r, &q); err != nil {
			fail(w, 400, err)
			return
		}
		q, err := validateQuestionIn(q, a.subjects)
		if err != nil {
			fail(w, 400, err)
			return
		}
		q.ID = guid()
		q.CreatedAt = nowISO()
		q.UpdatedAt = q.CreatedAt
		a.bank = append(a.bank, q)
		if err := a.saveBank(); err != nil {
			fail(w, 500, err)
			return
		}
		a.changed()
		send(w, 201, map[string]any{"question": q})
		return
	case strings.HasPrefix(p, "/api/teacher/questions/") && (r.Method == "PUT" || r.Method == "DELETE"):
		id := strings.TrimPrefix(p, "/api/teacher/questions/")
		i := -1
		for j, q := range a.bank {
			if subtle.ConstantTimeCompare([]byte(q.ID), []byte(id)) == 1 {
				i = j
				break
			}
		}
		if i < 0 {
			fail(w, 404, bad("Question not found."))
			return
		}
		if r.Method == "DELETE" {
			a.bank = append(a.bank[:i], a.bank[i+1:]...)
		} else {
			var q Question
			if err := jsonBody(r, &q); err != nil {
				fail(w, 400, err)
				return
			}
			q, err := validateQuestionIn(q, a.subjects)
			if err != nil {
				fail(w, 400, err)
				return
			}
			q.ID = a.bank[i].ID
			q.CreatedAt = a.bank[i].CreatedAt
			q.UpdatedAt = nowISO()
			a.bank[i] = q
		}
		if err := a.saveBank(); err != nil {
			fail(w, 500, err)
			return
		}
		a.changed()
		send(w, 200, map[string]bool{"ok": true})
		return
	case r.Method == "GET" && p == "/api/teacher/export":
		w.Header().Set("Content-Disposition", `attachment; filename="classroom-quest-question-backup.json"`)
		send(w, 200, map[string]any{"app": "Classroom Quest Offline", "version": 2, "subjects": a.subjects, "questions": a.bank})
		return
	case r.Method == "POST" && p == "/api/teacher/import":
		var b struct {
			App       string     `json:"app"`
			Version   int        `json:"version"`
			Questions []Question `json:"questions"`
			Subjects  []string   `json:"subjects"`
		}
		if err := jsonBody(r, &b); err != nil {
			fail(w, 400, err)
			return
		}
		if b.App != "Classroom Quest Offline" || (b.Version != 1 && b.Version != 2) {
			fail(w, 400, bad("Use a backup exported from Classroom Quest."))
			return
		}
		if len(b.Questions) > 3000 {
			fail(w, 400, bad("Import supports at most 3000 questions."))
			return
		}
		importSubjects := append([]string{}, subjects...)
		if b.Version == 2 {
			importSubjects = b.Subjects
		}
		if err := validateSubjects(importSubjects); err != nil {
			fail(w, 400, err)
			return
		}
		now := nowISO()
		clean := make([]Question, 0, len(b.Questions))
		for _, q := range b.Questions {
			q, err := validateQuestionIn(q, importSubjects)
			if err != nil {
				fail(w, 400, err)
				return
			}
			q.ID = guid()
			q.CreatedAt = now
			q.UpdatedAt = now
			clean = append(clean, q)
		}
		if err := a.backupBank(); err != nil {
			fail(w, 500, err)
			return
		}
		a.bank = clean
		a.subjects = importSubjects
		if err := a.saveSubjects(); err != nil {
			fail(w, 500, err)
			return
		}
		if err := a.saveBank(); err != nil {
			fail(w, 500, err)
			return
		}
		a.changed()
		send(w, 200, map[string]any{"ok": true, "count": len(clean)})
		return
	case r.Method == "POST" && strings.HasPrefix(p, "/api/teacher/game/"):
		var raw map[string]json.RawMessage
		if err := jsonBody(r, &raw); err != nil {
			fail(w, 400, err)
			return
		}
		var err error
		switch strings.TrimPrefix(p, "/api/teacher/game/") {
		case "new":
			var b struct {
				Subject string `json:"subject"`
				Target  int    `json:"target"`
				TeamA   string `json:"teamA"`
				TeamB   string `json:"teamB"`
			}
			d, _ := json.Marshal(raw)
			_ = json.Unmarshal(d, &b)
			err = a.game.newMatchIn(b.Subject, b.Target, b.TeamA, b.TeamB, a.bank, a.subjects)
		case "begin":
			err = a.game.begin()
		case "close":
			err = a.game.closeRound()
		case "next":
			err = a.game.nextQuestion()
		case "end":
			a.game = initialGame()
		case "release":
			var team string
			_ = json.Unmarshal(raw["team"], &team)
			err = a.game.resetTeam(team)
		default:
			fail(w, 404, bad("Page not found."))
			return
		}
		if err != nil {
			fail(w, 400, err)
			return
		}
		a.persist()
		send(w, 200, map[string]bool{"ok": true})
		return
	case r.Method == "POST" && p == "/api/teacher/shutdown":
		send(w, 200, map[string]any{"ok": true, "message": "Server is closing."})
		if a.shutdown != nil {
			go func() { time.Sleep(350 * time.Millisecond); a.shutdown() }()
		}
		return
	case r.Method == "GET" && p == "/api/health":
		send(w, 200, map[string]string{"app": "Classroom Quest Offline", "version": appVersion})
		return
	default:
		fail(w, 404, bad("Page not found."))
		return
	}
}
func (a *App) events(w http.ResponseWriter, r *http.Request) {
	flusher, ok := w.(http.Flusher)
	if !ok {
		fail(w, 500, bad("Live updates unavailable."))
		return
	}
	c := make(chan struct{}, 1)
	a.mu.Lock()
	a.watchers[c] = struct{}{}
	a.mu.Unlock()
	defer func() { a.mu.Lock(); delete(a.watchers, c); a.mu.Unlock() }()
	w.Header().Set("Content-Type", "text/event-stream; charset=utf-8")
	w.Header().Set("Cache-Control", "no-cache, no-transform")
	w.Header().Set("X-Accel-Buffering", "no")
	teacher := r.URL.Query().Get("role") == "teacher"
	token := r.URL.Query().Get("token")
	if len(token) > 128 {
		token = ""
	}
	snapshot := func() bool {
		a.mu.RLock()
		var data any
		if teacher {
			data = a.game.teacherStateIn(a.bank, a.subjects)
		} else {
			data = a.game.publicState(token)
		}
		a.mu.RUnlock()
		b, err := json.Marshal(data)
		if err != nil {
			return false
		}
		_, err = fmt.Fprintf(w, "event: snapshot\ndata: %s\n\n", b)
		if err == nil {
			flusher.Flush()
		}
		return err == nil
	}
	fmt.Fprint(w, "retry: 1600\n")
	if !snapshot() {
		return
	}
	timer := time.NewTicker(20 * time.Second)
	defer timer.Stop()
	for {
		select {
		case <-r.Context().Done():
			return
		case <-c:
			if !snapshot() {
				return
			}
		case <-timer.C:
			if _, err := fmt.Fprint(w, ": keepalive\n\n"); err != nil {
				return
			}
			flusher.Flush()
		}
	}
}
func notifyError(title, msg string) {
	log.Print(title, ": ", msg)
	if runtime.GOOS == "windows" {
		_ = exec.Command("powershell.exe", "-NoProfile", "-Command", fmt.Sprintf("Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.MessageBox]::Show('%s','Classroom Quest')", strings.ReplaceAll(msg, "'", "''"))).Run()
	}
}
func openBrowser(url string) {
	if runtime.GOOS == "windows" {
		_ = exec.Command("rundll32.exe", "url.dll,FileProtocolHandler", url).Start()
	} else if runtime.GOOS == "darwin" {
		_ = exec.Command("open", url).Start()
	} else {
		_ = exec.Command("xdg-open", url).Start()
	}
}
func main() {
	loggerFile := filepath.Join(appDataPath(), "startup.log")
	_ = os.MkdirAll(filepath.Dir(loggerFile), 0700)
	if f, err := os.OpenFile(loggerFile, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0600); err == nil {
		defer f.Close()
		log.SetOutput(f)
	}
	a, err := createApp(appDataPath())
	if err != nil {
		notifyError("Startup failed", err.Error())
		return
	}
	for port := 3000; port <= 3010; port++ {
		url := fmt.Sprintf("http://localhost:%d", port)
		if port == 3000 {
			client := &http.Client{Timeout: 350 * time.Millisecond}
			if resp, err := client.Get(url + "/api/health"); err == nil {
				var health struct {
					App string `json:"app"`
				}
				_ = json.NewDecoder(resp.Body).Decode(&health)
				resp.Body.Close()
				if health.App == "Classroom Quest Offline" {
					openBrowser(url + "/teacher")
					return
				}
			}
		}
		listener, err := net.Listen("tcp", fmt.Sprintf("0.0.0.0:%d", port))
		if err != nil {
			continue
		}
		a.port = port
		server := &http.Server{Handler: http.HandlerFunc(a.serve), ReadHeaderTimeout: 10 * time.Second, IdleTimeout: 60 * time.Second}
		a.shutdown = func() { ctx, cancel := newShutdownContext(); defer cancel(); _ = server.Shutdown(ctx) }
		log.Printf("Classroom Quest v%s listening port %d; data in %s", appVersion, port, a.directory)
		go func() { time.Sleep(250 * time.Millisecond); openBrowser(url + "/teacher") }()
		if err = server.Serve(listener); err != nil && err != http.ErrServerClosed {
			notifyError("Server stopped unexpectedly", err.Error())
		}
		return
	}
	notifyError("Could not start", "Ports 3000–3010 are already in use. Close other quiz servers and try again.")
}
