package main

import (
	"fmt"
	"net"
	"sort"
	"strings"
	"time"
)

// NetworkChoice represents a reachable candidate address *on this laptop*.
// It does not guarantee that another device can reach that address: only a
// successful request from a phone can establish that.
type NetworkChoice struct {
	URL       string `json:"url"`
	Address   string `json:"address"`
	Interface string `json:"interface"`
	Hint      string `json:"hint"`
	Primary   bool   `json:"primary"`
}

func preferredLocalIPv4() net.IP {
	// UDP Dial only asks the operating system to select a route/local address.
	// It sends no packets and does not require a working internet connection.
	c, err := net.DialTimeout("udp4", "1.1.1.1:53", 180*time.Millisecond)
	if err != nil {
		return nil
	}
	defer c.Close()
	if addr, ok := c.LocalAddr().(*net.UDPAddr); ok {
		return addr.IP.To4()
	}
	return nil
}

func addressHint(name string, ip net.IP) string {
	lower := strings.ToLower(name)
	if strings.HasPrefix(ip.String(), "192.168.137.") {
		return "Likely Windows hotspot"
	}
	if strings.Contains(lower, "wi-fi") || strings.Contains(lower, "wifi") || strings.Contains(lower, "wireless") || strings.Contains(lower, "wlan") {
		return "Wi-Fi network"
	}
	if strings.Contains(lower, "virtual") || strings.Contains(lower, "veth") || strings.Contains(lower, "docker") || strings.Contains(lower, "vmware") || strings.Contains(lower, "vbox") || strings.Contains(lower, "wsl") || strings.Contains(lower, "vpn") {
		return "Virtual or VPN adapter — may not work on phones"
	}
	if strings.Contains(lower, "ethernet") || strings.HasPrefix(lower, "eth") || strings.HasPrefix(lower, "en") {
		return "Wired network"
	}
	return "Local network"
}

func rankChoice(c NetworkChoice) int {
	score := 0
	if c.Primary {
		score += 50
	}
	if c.Hint == "Likely Windows hotspot" {
		score += 40
	}
	if c.Hint == "Wi-Fi network" {
		score += 20
	}
	if strings.HasPrefix(c.Hint, "Virtual") {
		score -= 50
	}
	return score
}

func choicesFromInterfaces(port int, interfaces []net.Interface, preferred net.IP) []NetworkChoice {
	choices := make([]NetworkChoice, 0)
	seen := map[string]bool{}
	for _, nic := range interfaces {
		if nic.Flags&net.FlagUp == 0 || nic.Flags&net.FlagLoopback != 0 {
			continue
		}
		addrs, err := nic.Addrs()
		if err != nil {
			continue
		}
		for _, addr := range addrs {
			ipNet, ok := addr.(*net.IPNet)
			if !ok {
				continue
			}
			ip := ipNet.IP.To4()
			// Only private IPv4 LAN addresses are accepted by the web server.
			if ip == nil || !ip.IsPrivate() {
				continue
			}
			if seen[ip.String()] {
				continue
			}
			seen[ip.String()] = true
			choices = append(choices, NetworkChoice{
				URL:       fmt.Sprintf("http://%s:%d", ip.String(), port),
				Address:   ip.String(),
				Interface: nic.Name,
				Hint:      addressHint(nic.Name, ip),
				Primary:   preferred != nil && preferred.Equal(ip),
			})
		}
	}
	sort.SliceStable(choices, func(i, j int) bool {
		if rankChoice(choices[i]) != rankChoice(choices[j]) {
			return rankChoice(choices[i]) > rankChoice(choices[j])
		}
		return choices[i].URL < choices[j].URL
	})
	return choices
}

func networkChoices(port int) []NetworkChoice {
	nics, err := net.Interfaces()
	if err != nil {
		return []NetworkChoice{}
	}
	return choicesFromInterfaces(port, nics, preferredLocalIPv4())
}

const liveClientWindow = 75 * time.Second

func (a *App) noteStudentBrowser(clientID string) {
	current := time.Now()
	for id, last := range a.clients {
		if current.Sub(last) >= liveClientWindow {
			delete(a.clients, id)
		}
	}
	if len(a.clients) >= 64 {
		oldestID := ""
		var oldest time.Time
		for id, t := range a.clients {
			if oldestID == "" || t.Before(oldest) {
				oldestID = id
				oldest = t
			}
		}
		if oldestID != "" {
			delete(a.clients, oldestID)
		}
	}
	a.clients[clientID] = current
}

func (a *App) activeStudentBrowsers() int {
	count := 0
	for _, last := range a.clients {
		if time.Since(last) < liveClientWindow {
			count++
		}
	}
	return count
}

func validClientID(id string) bool {
	if len(id) < 12 || len(id) > 80 {
		return false
	}
	for _, c := range id {
		if (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '_' || c == '-' {
			continue
		}
		return false
	}
	return true
}
