# Classroom Quest Offline v3.0 — by TechEdz

**Free, open-source, offline quiz battles for elementary and secondary school teachers.**

A teacher runs one Windows laptop application. Two student teams use smartphone browsers over a shared **local Wi-Fi network**, which does **not** require internet. A hotspot on a compatible phone, Windows laptop hotspot, or router can host the local network.

## Highlights

- Teacher-friendly, separate **Dashboard**, **Question bank**, **Instructions**, and **Pupils View** pages.
- **Teacher-managed learning areas**: add/rename/remove subjects for any grade level. Initially: GMRC, Makabansa, Math, Science, English and Filipino. Starter questions are **examples only** and should be checked for classroom/curriculum suitability.
- Add/edit/delete multiple-choice questions. Renaming a subject retains all associated questions.
- Removing a subject with questions requires confirmation, automatically saves a local safety backup, then removes its associated questions.
- **1 point per correct answer**, teacher-set win target, and tie-breaker when teams reach the target simultaneously.
- Optional correct/wrong answer sounds on students' phones; optional **original, locally generated chill music loop** on the teacher laptop while questions are active. Each device can mute its sounds. No external audio assets or online service required.
- QR-code join instructions, automatic local address detection, and connection check-ins.
- Teacher-only API restricted to the laptop's own localhost, with validation and anti-cross-origin protections.
- Question data saved locally in the Windows user's AppData folder and included in JSON backups.
- No Node.js, npm, cloud server, account, telemetry, or internet connection required during gameplay.

## Teacher quick start

1. Install the supplied Windows installer (Windows 10/11, 64-bit), then open the desktop shortcut.
2. On **Instructions**, choose phone hotspot, laptop hotspot, or existing router. Connect the laptop and both phones to the same network.
3. Choose the laptop's address and have both phones scan the join QR code (scanning does not automatically join Wi-Fi).
4. On **Question bank**, pick a learning area or open **Manage learning areas** to add/rename/remove subjects. Add your own curriculum-appropriate questions.
5. On **Dashboard**, choose learning area and target points, then create a match.
6. The pupils join Team A and Team B. Press **Begin questions**.
7. Under **Sound & background music** on the dashboard, optionally turn on music or disable sound effects. Students can mute their sounds on their phones.

## Installation and development

- Teacher guide: [`docs/QUICK_START.txt`](docs/QUICK_START.txt)
- Build from source: [`docs/BUILD_FROM_SOURCE.md`](docs/BUILD_FROM_SOURCE.md)
- Security/privacy: [`SECURITY.md`](SECURITY.md)
- How to contribute: [`CONTRIBUTING.md`](CONTRIBUTING.md)
- MIT License: [`LICENSE`](LICENSE)

Written in Go 1.23+ (standard library) with vanilla HTML, CSS, JavaScript; SSE for real-time updates, JSON for local persistence. The Windows desktop installer is implemented in Go.

## Privacy, safety & limitations

- Team names, scores and teacher-written question content remain on the laptop; there is no login server, analytics, or tracking. Do not place personally identifiable pupil data in question prompts or team names.
- The local website is served over **HTTP** and is designed for a **trusted, password-protected classroom network only**. Do not port-forward it to the internet, or use guest Wi-Fi with unknown devices.
- Use **Private** firewall allow rules if needed. Do not disable Windows Firewall.
- The teacher interface and subject management are available only from localhost, not from pupils' devices.
- Some hotspots block local device-to-device traffic. Select a different supported hotspot/network when needed.
- Audio requires user interaction due to browser playback restrictions, and individual phone volume settings affect sound. Music is optional and may need to be re-enabled after reloading the page.
- Source can be built on Windows with Go. Included Windows binaries are **unsigned** and need **real-world testing** on the target computer/phone configurations before public deployment.

## Audio and attribution

The background loop in `app/public/chill-loop.wav` was composed and synthesized programmatically for this release, with no sampled third-party recordings. The code, interface and embedded audio in this package are released under the MIT License.

**TechEdz — classroom technology that works even when internet doesn't.**
